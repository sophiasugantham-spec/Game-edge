"""GameEdge revised simulator.

Model (revised manuscript):
  * Parallel local / remote execution: T_i = max(T_loc,i , T_tx,ij + T_edge,ij)
  * Every execution stage is an M/M/1 queue with Poisson task arrivals nu_i:
      local CPU     : service rate f_loc / ((1-x) C)
      uplink slice  : service rate r_ij / (x D),  r_ij = b_ij * c_ij  (b in Hz)
      edge CPU slice: service rate f_ij / (x C)
    sojourn = 1/(mu - nu). Uplink -> edge CPU is a tandem of M/M/1 queues
    (Burke), so the edge-path sojourn is the sum. Capacity is counted once:
    each user is served by its own CPU/bandwidth slice.
  * Stability: per-queue utilisation <= RHO_MAX.
  * Server utility: R - O - omega V - kappa * mean normalised edge latency.
"""
import numpy as np

RHO_MAX = 0.98
X_ACT = 1e-6
GOLD = (np.sqrt(5.0) - 1.0) / 2.0
BIG = 1e9

DEFAULT = dict(
    nu_lo=0.5, nu_hi=2.5, nu_scale=1.0,
    w_lo=0.65, w_hi=0.80,
    xi=0.5, gam=0.5, omega=0.2, kappa=1.0,
    pi_scale=1.0, beta_scale=1.0,
    Tmax_scale=1.0,
    rho_x=0.25, eps=1e-4, Tc_max=120, TA_max=12, cleanup_passes=5,
    floc_lo=1e9, floc_hi=3e9, F_lo=5e9, F_hi=12e9, B_lo=50e6, B_hi=200e6,
)


# ----------------------------------------------------------------- scenario
def gen_scenario(N, M, seed, cfg=None):
    cfg = dict(DEFAULT, **(cfg or {}))
    rng = np.random.default_rng(seed)
    # Same draw order and seeds as the authors' original notebook
    # (D, C, Tmax, f_loc, nu, w, Fmax, Bmax, pi, beta, SNR). Ranges that are
    # recalibrated are linear maps of the same uniform draws, so every
    # scenario stays paired with the original one.
    D = rng.uniform(0.1, 2.0, N) * 8e6            # bits
    C = rng.uniform(5e7, 5e8, N)                    # cycles
    Tmax = rng.uniform(0.1, 0.5, N) * cfg['Tmax_scale']   # s
    floc_u = (rng.uniform(1.0, 3.0, N) - 1.0) / 2.0
    nu_u = (rng.uniform(0.05, 0.15, N) - 0.05) / 0.10
    w_u = (rng.uniform(0.65, 0.80, N) - 0.65) / 0.15
    F_u = (rng.uniform(5.0, 12.0, M) - 5.0) / 7.0
    B_u = (rng.uniform(50.0, 200.0, M) - 50.0) / 150.0
    pi = rng.uniform(0.01, 0.10, M) * cfg['pi_scale']      # per GHz
    beta = rng.uniform(0.001, 0.005, M) * cfg['beta_scale']  # per MHz
    snr_db = rng.uniform(5, 20, (N, M))
    floc = cfg['floc_lo'] + floc_u * (cfg['floc_hi'] - cfg['floc_lo'])
    nu = (cfg['nu_lo'] + nu_u * (cfg['nu_hi'] - cfg['nu_lo'])) * cfg['nu_scale']
    w = cfg['w_lo'] + w_u * (cfg['w_hi'] - cfg['w_lo'])
    F = cfg['F_lo'] + F_u * (cfg['F_hi'] - cfg['F_lo'])
    B = cfg['B_lo'] + B_u * (cfg['B_hi'] - cfg['B_lo'])
    c = np.log2(1.0 + 10 ** (snr_db / 10.0))
    Rref = pi * F / 1e9 + beta * B / 1e6
    sc = dict(N=N, M=M, seed=seed, D=D, C=C, Tmax=Tmax, floc=floc, nu=nu, w=w, alpha=1 - w,
              F=F, B=B, c=c, pi=pi, beta=beta, Rref=Rref, Cref=Rref.max(),
              aF=(pi * F / 1e9) / Rref, aB=(beta * B / 1e6) / Rref, cfg=cfg)
    return sc


# ----------------------------------------------------------- latency model
np.seterr(all='ignore')


def t_loc(x, C, floc, nu):
    y = (1.0 - x) * C
    den = floc - nu * y
    t = y / den
    t[den <= 0] = BIG
    t[y <= 0] = 0.0
    return t


def t_edge(x, C, D, nu, f, r):
    a = x * D
    b = x * C
    d1 = r - nu * a
    d2 = f - nu * b
    t = a / d1 + b / d2
    t[(d1 <= 0) | (d2 <= 0)] = BIG
    t[x <= 0] = 0.0
    return t


def t_total(x, C, D, nu, floc, f, r):
    x = np.asarray(x, float)
    if not (x.shape == np.shape(C) == np.shape(f)):
        shp = np.broadcast_shapes(x.shape, np.shape(C), np.shape(D), np.shape(f))
        x = np.broadcast_to(x, shp).astype(float)
    return np.maximum(t_loc(x, C, floc, nu), t_edge(x, C, D, nu, f, r))


def _golden(fun, lo, hi, it=42):
    """vectorised golden-section search; one function evaluation per iteration"""
    a, b = lo.astype(float).copy(), hi.astype(float).copy()
    c = b - GOLD * (b - a)
    d = a + GOLD * (b - a)
    fc, fd = fun(c), fun(d)
    for _ in range(it):
        m = fc < fd                       # minimum in [a, d]
        b = np.where(m, d, b)
        a = np.where(m, a, c)
        newpt = np.where(m, b - GOLD * (b - a), a + GOLD * (b - a))
        fn = fun(newpt)
        d, fd, c, fc = (np.where(m, c, newpt), np.where(m, fc, fn),
                        np.where(m, newpt, d), np.where(m, fn, fd))
    x = 0.5 * (a + b)
    return x, fun(x)


def user_br(C, D, floc, nu, Tmax, w, alpha, f, r, pc):
    """Vectorised user best response for a candidate server with fixed (f, r).
    pc = normalised service-cost coefficient per unit offloading fraction.
    Returns x*, J*, T*, feasible flag, and the latency-minimising x (best effort)."""
    C, D, floc, nu, Tmax, w, alpha, f, r, pc = np.broadcast_arrays(
        *[np.asarray(v, float) for v in (C, D, floc, nu, Tmax, w, alpha, f, r, pc)])
    lo = np.maximum(X_ACT, 1.0 - RHO_MAX * floc / (nu * C))
    with np.errstate(divide='ignore', invalid='ignore'):
        hi = np.minimum.reduce([np.ones_like(C), RHO_MAX * f / (nu * C), RHO_MAX * r / (nu * D)])
    hi = np.where(np.isfinite(hi), hi, 0.0) * (1 - 1e-12)
    ok = lo < hi
    lo_s = np.where(ok, lo, 0.0)
    hi_s = np.where(ok, hi, 1.0)
    T = lambda x: t_total(x, C, D, nu, floc, f, r)
    xT, Tmin = _golden(T, lo_s, hi_s)
    feas = ok & (Tmin <= Tmax)
    # deadline interval endpoints
    TL = T(lo_s)
    TH = T(hi_s)
    L = np.where(TL <= Tmax, lo_s, 0.0)
    a_, b_ = lo_s.copy(), xT.copy()
    for _ in range(36):
        m = 0.5 * (a_ + b_)
        g = T(m) <= Tmax
        b_ = np.where(g, m, b_)
        a_ = np.where(g, a_, m)
    L = np.where(TL <= Tmax, lo_s, b_)
    a_, b_ = xT.copy(), hi_s.copy()
    for _ in range(36):
        m = 0.5 * (a_ + b_)
        g = T(m) <= Tmax
        a_ = np.where(g, m, a_)
        b_ = np.where(g, b_, m)
    H = np.where(TH <= Tmax, hi_s, a_)
    L = np.where(feas, L, xT)
    H = np.where(feas, np.maximum(H, L), xT)
    J = lambda x: w * T(x) / Tmax + alpha * x * pc
    xJ, Jv = _golden(J, L, H)
    TJ = T(xJ)
    feas = feas & (TJ <= Tmax * (1 + 1e-9))
    Jv = np.where(feas, Jv, np.inf)
    return xJ, Jv, TJ, feas, xT


def local_option(sc):
    T0 = t_loc(np.zeros(sc['N']), sc['C'], sc['floc'], sc['nu'])
    stable = sc['nu'] * sc['C'] <= RHO_MAX * sc['floc']
    feas = stable & (T0 <= sc['Tmax'])
    J0 = np.where(feas, sc['w'] * T0 / sc['Tmax'], np.inf)
    return J0, T0, feas


# --------------------------------------------------------- server solver
def _solve_resource(sid, M, A, K, e, cap, two_c):
    """max sum_k [A_k p_k - c p_k^2 - K_k/(p_k cap_k - e_k)]  s.t. p >= lb, sum p <= 1
    (per server). Uses KKT with per-server multiplier; Newton inner/outer."""
    n = len(sid)
    if n == 0:
        return np.zeros(0), np.zeros(M), np.zeros(M, bool)
    lb = e / (RHO_MAX * cap)
    lb_sum = np.bincount(sid, lb, minlength=M)
    infeas = lb_sum > 1.0
    lbu = lb * (1 + 1e-9) + 1e-12

    def h(p, lam):
        u = p * cap - e
        return A - lam - two_c * p + K * cap / u ** 2

    def hp(p):
        u = p * cap - e
        return -two_c - 2.0 * K * cap ** 2 / u ** 3

    a3 = two_c / cap
    Kc = K * cap
    u_lb = lbu * cap - e
    u_hi = cap - e

    def p_of(lam_s, p0=None):
        # stationarity h = 0  <=>  a3 u^3 - beta u^2 - K cap = 0,  u = p cap - e > 0,
        # which has exactly one positive root (Descartes); closed form + Newton polish.
        beta = A - lam_s - two_c * e / cap
        Bc = -beta / a3
        Dc = -Kc / a3
        P = -Bc ** 2 / 3.0
        Q = 2.0 * Bc ** 3 / 27.0 + Dc
        disc = (Q / 2.0) ** 2 + (P / 3.0) ** 3
        sq = np.sqrt(np.maximum(disc, 0.0))
        t1 = np.cbrt(-Q / 2.0 + sq) + np.cbrt(-Q / 2.0 - sq)
        rP = np.sqrt(np.maximum(-P / 3.0, 0.0))
        arg = np.clip(-Q / 2.0 / np.maximum(rP ** 3, 1e-300), -1.0, 1.0)
        t2 = 2.0 * rP * np.cos(np.arccos(arg) / 3.0)
        u = np.where(disc >= 0, t1, t2) - Bc / 3.0
        u = np.where(Kc <= 0, np.maximum(beta / a3, 0.0), u)
        u = np.clip(u, u_lb, u_hi)
        for _ in range(2):   # Newton polish of g(u) = a3 u^3 - beta u^2 - Kc
            g = a3 * u ** 3 - beta * u ** 2 - Kc
            dg = 3 * a3 * u ** 2 - 2 * beta * u
            un = u - np.where(np.abs(dg) > 0, g / dg, 0.0)
            u = np.where(np.isfinite(un), np.clip(un, u_lb, u_hi), u)
        p = (u + e) / cap
        hi_ok = h(np.ones(n), lam_s) >= 0
        lo_ok = h(lbu, lam_s) <= 0
        p = np.where(hi_ok, 1.0, np.where(lo_ok, lbu, np.clip(p, lbu, 1.0)))
        return p, hi_ok | lo_ok

    lam = np.zeros(M)
    p, atb = p_of(lam[sid], lbu)
    S = np.bincount(sid, p, minlength=M)
    need = (S > 1.0 + 1e-12) & ~infeas
    if need.any():
        lo = np.zeros(M)
        hi = np.zeros(M)
        hmax = np.zeros(M)
        np.maximum.at(hmax, sid, h(lbu, 0.0))
        hi[:] = np.maximum(hmax, 1e-6)
        lam = np.where(need, np.sqrt(hi * 1e-6), 0.0)
        for _ in range(80):
            p, atb = p_of(lam[sid], p)
            S = np.bincount(sid, p, minlength=M)
            g = S - 1.0
            act = need & (np.abs(g) > 1e-10)
            if not act.any():
                break
            lo = np.where(need & (g > 0), lam, lo)
            hi = np.where(need & (g < 0), lam, hi)
            dS = np.bincount(sid, np.where(atb, 0.0, 1.0 / hp(p)), minlength=M)
            with np.errstate(divide='ignore', invalid='ignore'):
                lam_n = lam - g / dS
            bad = ~np.isfinite(lam_n) | (lam_n <= lo) | (lam_n >= hi)
            mid = np.where(lo > 0, np.sqrt(lo * hi), hi * 1e-3)
            lam = np.where(act, np.where(bad, mid, lam_n), lam)
    return p, lam, infeas


def solve_slots(sc, users, sid, xs, omega, kappa, pp=None, ss=None, passes=2):
    """Server best response for arbitrary (user, server) slots; each server j maximises
    its utility over the slots with sid == j. Returns shares p, s per slot."""
    M = sc['M']
    n = np.bincount(sid, minlength=M).astype(float)
    nn = n[sid]
    C, D, nu, Tm = sc['C'][users], sc['D'][users], sc['nu'][users], sc['Tmax'][users]
    cij = sc['c'][users, sid]
    F, Bw = sc['F'][sid], sc['B'][sid] * cij
    eF = nu * xs * C
    eB = nu * xs * D
    KF = (kappa / nn) * xs * C / Tm
    KB = (kappa / nn) * xs * D / Tm
    pp = np.full(len(users), 0.5) / nn if pp is None else pp
    ss = np.full(len(users), 0.5) / nn if ss is None else ss
    twoxi = 2 * sc['cfg']['xi'] * np.ones(len(users))
    twog = 2 * sc['cfg']['gam'] * np.ones(len(users))
    for k in range(passes):
        if omega > 0:
            q = 0.5 * (pp + ss)
            qbar = np.bincount(sid, q, minlength=M) / np.maximum(n, 1)
            lin = omega * (q - qbar[sid]) / nn
        else:
            lin = 0.0
        AF = xs * sc['aF'][sid] - lin
        AB = xs * sc['aB'][sid] - lin
        pp, lamF, infF = _solve_resource(sid, M, AF, KF, eF, F, twoxi)
        ss, lamB, infB = _solve_resource(sid, M, AB, KB, eB, Bw, twog)
        if omega <= 0:
            break
    return pp, ss, infF | infB


def server_solve(sc, a, x, p_prev=None, s_prev=None, omega=None, kappa=None, passes=2):
    """Best-response CPU/BW shares for every server given association a and x.
    Returns p, s (normalised shares per user, 0 if not active) and per-server infeasibility."""
    cfg = sc['cfg']
    omega = cfg['omega'] if omega is None else omega
    kappa = cfg['kappa'] if kappa is None else kappa
    N, M = sc['N'], sc['M']
    idx = np.nonzero(a >= 0)[0]
    p = np.zeros(N)
    s = np.zeros(N)
    if len(idx) == 0:
        return p, s, np.zeros(M, bool)
    pp = p_prev[idx] if p_prev is not None else None
    ss = s_prev[idx] if s_prev is not None else None
    if pp is not None and np.any(pp <= 0):
        pp = ss = None
    pp, ss, inf = solve_slots(sc, idx, a[idx], x[idx], omega, kappa, pp, ss, passes)
    p[idx] = pp
    s[idx] = ss
    return p, s, inf


def server_utility(sc, a, x, p, s, omega=None, kappa=None):
    cfg = sc['cfg']
    omega = cfg['omega'] if omega is None else omega
    kappa = cfg['kappa'] if kappa is None else kappa
    M = sc['M']
    U = np.zeros(M)
    idx = np.nonzero(a >= 0)[0]
    if len(idx) == 0:
        return U
    sid = a[idx]
    n = np.bincount(sid, minlength=M).astype(float)
    xs = x[idx]
    R = np.bincount(sid, xs * (sc['aF'][sid] * p[idx] + sc['aB'][sid] * s[idx]), minlength=M)
    O = sc['cfg']['xi'] * np.bincount(sid, p[idx] ** 2, minlength=M) + \
        sc['cfg']['gam'] * np.bincount(sid, s[idx] ** 2, minlength=M)
    q = 0.5 * (p[idx] + s[idx])
    qbar = np.bincount(sid, q, minlength=M) / np.maximum(n, 1)
    V = np.bincount(sid, (q - qbar[sid]) ** 2, minlength=M) / np.maximum(n, 1)
    V = np.where(n >= 2, V, 0.0)
    f = p[idx] * sc['F'][sid]
    r = s[idx] * sc['B'][sid] * sc['c'][idx, sid]
    Te = t_edge(xs, sc['C'][idx], sc['D'][idx], sc['nu'][idx], f, r) / sc['Tmax'][idx]
    Q = np.bincount(sid, Te, minlength=M) / np.maximum(n, 1)
    return R - O - omega * V - kappa * Q


# ------------------------------------------------------------- evaluation
def user_eval(sc, a, x, p, s):
    """T, J, normalised service cost for every user under profile (a, x, p, s)."""
    N = sc['N']
    T = t_loc(x, sc['C'], sc['floc'], sc['nu']).astype(float)
    Cs = np.zeros(N)
    idx = np.nonzero(a >= 0)[0]
    if len(idx):
        sid = a[idx]
        f = p[idx] * sc['F'][sid]
        r = s[idx] * sc['B'][sid] * sc['c'][idx, sid]
        Te = t_edge(x[idx], sc['C'][idx], sc['D'][idx], sc['nu'][idx], f, r)
        T[idx] = np.maximum(T[idx], Te)
        Cs[idx] = x[idx] * (sc['pi'][sid] * f / 1e9 + sc['beta'][sid] * r / sc['c'][idx, sid] / 1e6) / sc['Cref']
    J = sc['w'] * T / sc['Tmax'] + sc['alpha'] * Cs
    return T, J, Cs


def stable_mask(sc, a, x, p, s):
    N = sc['N']
    ok = sc['nu'] * (1 - x) * sc['C'] <= RHO_MAX * sc['floc'] * (1 + 1e-9)
    idx = np.nonzero(a >= 0)[0]
    if len(idx):
        sid = a[idx]
        f = p[idx] * sc['F'][sid]
        r = s[idx] * sc['B'][sid] * sc['c'][idx, sid]
        ok[idx] &= (sc['nu'][idx] * x[idx] * sc['C'][idx] <= RHO_MAX * f * (1 + 1e-9)) & \
                   (sc['nu'][idx] * x[idx] * sc['D'][idx] <= RHO_MAX * r * (1 + 1e-9))
    return ok


def price_coef(sc, i, j, p, s):
    """normalised cost per unit x for user(s) i on server(s) j with shares p,s"""
    return (sc['pi'][j] * p * sc['F'][j] / 1e9 + sc['beta'][j] * s * sc['B'][j] / 1e6) / sc['Cref']


def br_on_current(sc, a, x, p, s, users):
    """best response of active users on their current server with fixed shares"""
    j = a[users]
    f = p[users] * sc['F'][j]
    r = s[users] * sc['B'][j] * sc['c'][users, j]
    pc = price_coef(sc, users, j, p[users], s[users])
    return user_br(sc['C'][users], sc['D'][users], sc['floc'][users], sc['nu'][users],
                   sc['Tmax'][users], sc['w'][users], sc['alpha'][users], f, r, pc)


def ideal_and_oracle(sc):
    """T_ideal: best achievable latency of a user alone (local, or any server with all
    its capacity). Oracle admission: whether any option meets the deadline alone."""
    N, M = sc['N'], sc['M']
    J0, T0, f0 = local_option(sc)
    T0 = np.where(sc['nu'] * sc['C'] <= RHO_MAX * sc['floc'], T0, np.inf)
    ii = np.repeat(np.arange(N), M)
    jj = np.tile(np.arange(M), N)
    f = sc['F'][jj]
    r = sc['B'][jj] * sc['c'][ii, jj]
    lo = np.maximum(X_ACT, 1.0 - RHO_MAX * sc['floc'][ii] / (sc['nu'][ii] * sc['C'][ii]))
    hi = np.minimum.reduce([np.ones(len(ii)), RHO_MAX * f / (sc['nu'][ii] * sc['C'][ii]),
                            RHO_MAX * r / (sc['nu'][ii] * sc['D'][ii])]) * (1 - 1e-12)
    ok = lo < hi
    T = lambda x: t_total(x, sc['C'][ii], sc['D'][ii], sc['nu'][ii], sc['floc'][ii], f, r)
    _, Tm = _golden(T, np.where(ok, lo, 0), np.where(ok, hi, 1))
    Tm = np.where(ok, Tm, np.inf).reshape(N, M)
    Tid = np.minimum(T0, Tm.min(axis=1))
    return Tid, Tid <= sc['Tmax']
