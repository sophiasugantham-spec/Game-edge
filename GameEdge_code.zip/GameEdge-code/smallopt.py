"""Exhaustive small-instance optimum (social cost = sum of normalised user costs J_i).

For every association profile in {local, server 1, ..., server M}^N the continuous problem
(offloading fractions, CPU and bandwidth shares) is solved with multi-start SLSQP in
epigraph form (t_i >= T_loc,i, t_i >= T_edge,i). Starts include every heuristic's own
solution when its association matches, so the reported optimum is never worse than any method.
"""
import itertools
import numpy as np
from scipy.optimize import minimize
import sim
from sim import RHO_MAX


def solve_assoc(sc, assoc, starts):
    N = sc['N']
    J0, T0, f0 = sim.local_option(sc)
    loc = [i for i in range(N) if assoc[i] < 0]
    if any(not f0[i] for i in loc):
        return np.inf, None
    base = float(sum(J0[i] for i in loc))
    off = [i for i in range(N) if assoc[i] >= 0]
    k = len(off)
    if k == 0:
        return base, None
    off = np.array(off)
    js = np.array([assoc[i] for i in off])
    C, D, nu, Tm = sc['C'][off], sc['D'][off], sc['nu'][off], sc['Tmax'][off]
    fl, w, al = sc['floc'][off], sc['w'][off], sc['alpha'][off]
    F, Bw = sc['F'][js], sc['B'][js] * sc['c'][off, js]
    pc_den = sc['Cref']

    def unpack(z):
        return z[:k], z[k:2 * k], z[2 * k:3 * k], z[3 * k:]

    def obj(z):
        x, p, s, t = unpack(z)
        cost = x * (sc['pi'][js] * p * sc['F'][js] / 1e9 + sc['beta'][js] * s * sc['B'][js] / 1e6) / pc_den
        return base + np.sum(w * t / Tm + al * cost)

    def cons(z):
        x, p, s, t = unpack(z)
        out = []
        tl = sim.t_loc(x.copy(), C, fl, nu)
        te = sim.t_edge(x.copy(), C, D, nu, p * F, s * Bw)
        out += list((t - tl) / Tm)
        out += list((t - te) / Tm)
        out += list((Tm - t) / Tm)
        out += list(RHO_MAX * p * F / (nu * C) - x)                  # edge CPU stability
        out += list(RHO_MAX * s * Bw / (nu * D) - x)                 # uplink stability
        out += list(x - (1 - RHO_MAX * fl / (nu * C)))               # local stability
        for j in np.unique(js):
            m = js == j
            out.append(1 - p[m].sum())
            out.append(1 - s[m].sum())
        return np.array(out)

    bounds = [(1e-6, 1)] * k + [(1e-6, 1)] * (2 * k) + [(0, None)] * k
    best = np.inf
    for st in starts(off, js):
        x, p, s = st
        T = sim.t_total(x, C, D, nu, fl, p * F, s * Bw)
        z0 = np.r_[x, p, s, np.minimum(np.where(T < 1e8, T, Tm), Tm)]
        try:
            r = minimize(obj, z0, method='SLSQP', bounds=bounds,
                         constraints=[{'type': 'ineq', 'fun': cons}],
                         options={'maxiter': 400, 'ftol': 1e-12})
        except Exception:
            continue
        z = r.x
        c = cons(z)
        if np.all(c >= -1e-7):
            x, p, s, t = unpack(z)
            # evaluate true cost (t may exceed T slightly; use actual T)
            T = sim.t_total(x, C, D, nu, fl, p * F, s * Bw)
            if np.all(T <= Tm * (1 + 1e-6)):
                cost = x * (sc['pi'][js] * p * sc['F'][js] / 1e9 + sc['beta'][js] * s * sc['B'][js] / 1e6) / pc_den
                val = base + np.sum(w * T / Tm + al * cost)
                best = min(best, val)
    return best, None


def social_cost(sc, out):
    T, J, Cs = sim.user_eval(sc, out['a'], out['x'], out['p'], out['s'])
    adm = out['a'] != -2
    return float(np.where(adm, J, 2.0).sum())


def optimum(sc, method_outs):
    N, M = sc['N'], sc['M']
    best = min(social_cost(sc, o) for o in method_outs.values())
    best_src = 'heuristic'

    for assoc in itertools.product(range(-1, M), repeat=N):
        assoc = np.array(assoc)

        def starts(off, js, assoc=assoc):
            k = len(off)
            n = np.bincount(js, minlength=M)
            eq = 1.0 / n[js]
            st = [(np.full(k, 0.5), eq, eq), (np.full(k, 0.9), eq, eq), (np.full(k, 0.2), eq, eq)]
            for o in method_outs.values():
                if np.array_equal(np.where(o['a'] >= 0, o['a'], -1), assoc):
                    st.append((np.clip(o['x'][off], 1e-6, 1), np.clip(o['p'][off], 1e-6, 1),
                               np.clip(o['s'][off], 1e-6, 1)))
            return st
        v, _ = solve_assoc(sc, assoc, starts)
        if v < best - 1e-9:
            best = v
            best_src = 'enumeration'
    return best, best_src
