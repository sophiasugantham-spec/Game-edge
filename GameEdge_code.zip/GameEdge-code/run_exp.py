"""Experiment runner (resumable: one pickle per job).
usage: python run_exp.py E1|E2|E5|E6|E7 [workers]
"""
import os, sys, pickle, time, traceback
import numpy as np
from multiprocessing import Pool
import sim, algos

BASE = dict(nu_lo=1.0, nu_hi=5.0)          # recalibrated nominal arrival rates (tasks/s)
OUT = '/home/claude/gameedge/results'
METHODS = [('Proposed', algos.run_proposed), ('Greedy', algos.run_greedy),
           ('Random', algos.run_random), ('Centralized', algos.run_centralized),
           ('PG-BR', algos.run_pgbr), ('JTORA-LS', algos.run_jtora)]
E1_LOADS = list(range(10, 101, 10))
E1_REPS = 50
E1_EPS_N = (20, 60, 100)
E2_TOPO = [(10, 5), (10, 10), (10, 20), (5, 10), (20, 10)]     # (M, users per server)
E2_LOADS = [1.0, 2.0, 4.0, 6.0]
E2_REPS = 10
ABL_REPS = 30
SENS_REPS = 30


def e1_seed(N, r):
    return 42 + 10000 * N + r


def run_methods(sc, methods, eps_for=(), keep_hist=False):
    Tid, orc = sim.ideal_and_oracle(sc)
    rec = dict(oracle_adm=100 * orc.mean(), N=sc['N'], M=sc['M'])
    users = {}
    for name, fn in methods:
        out = fn(sc, keep_hist=True) if (name == 'Proposed' and keep_hist) else fn(sc)
        m, u = algos.metrics(sc, out, Tid)
        m['runtime'] = out['runtime']
        if name == 'Proposed':
            for k in ('rounds', 'cont_last', 'cont_total', 'residual', 'converged',
                      'assoc_changes_last', 'scalars_per_user', 'final_fix'):
                m[k] = out[k]
            m['round_log'] = out['round_log']
            if keep_hist:
                m['hist'] = out['hist']
        if name in eps_for:
            om = sc['cfg']['omega'] if name == 'Proposed' else 0.0
            g = algos.eps_gap(sc, out, omega=om)
            m.update({'eps_' + k if not k.startswith('eps') else k: v for k, v in g.items()})
        rec[name] = m
        users[name] = u
    rec['users'] = users
    return rec


def job(args):
    exp, key, kw = args
    path = os.path.join(OUT, exp, key + '.pkl')
    if os.path.exists(path):
        return key, 'skip'
    t0 = time.time()
    try:
        if exp == 'E1':
            N, r = kw['N'], kw['r']
            sc = sim.gen_scenario(N, 10, e1_seed(N, r), BASE)
            eps_for = ('Proposed', 'Greedy', 'Random') if N in E1_EPS_N else ()
            rec = run_methods(sc, METHODS, eps_for, keep_hist=(N == 100))
        elif exp == 'E2':
            M, k, L, r = kw['M'], kw['k'], kw['L'], kw['r']
            N = M * k
            cfg = dict(BASE, Tmax_scale=4.0, nu_scale=L)
            sc = sim.gen_scenario(N, M, 3000042 + 10000 * N + 1000 * M + r, cfg)
            eps_for = ('Proposed',) if (M == 10 and k == 10) else ()
            rec = run_methods(sc, METHODS, eps_for)
        elif exp in ('E5', 'E6'):
            N = 100
            cfg = dict(BASE, **kw['cfg'])
            Mv = kw.get('M', 10)
            sc = sim.gen_scenario(N, Mv, e1_seed(N, kw['r']), cfg)
            rec = run_methods(sc, METHODS[:1])
            rec['users'] = None
        elif exp == 'E7':
            import smallopt
            sc = sim.gen_scenario(6, 2, kw['seed'], BASE)
            outs = {n: f(sc) for n, f in METHODS}
            opt, src = smallopt.optimum(sc, outs)
            rec = dict(opt=opt, src=src, seed=kw['seed'])
            for n, o in outs.items():
                T, J, Cs = sim.user_eval(sc, o['a'], o['x'], o['p'], o['s'])
                rec[n] = dict(cost=smallopt.social_cost(sc, o), T=float(T.mean()))
        rec['kw'] = kw
        rec['wall'] = time.time() - t0
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + '.tmp', 'wb') as f:
            pickle.dump(rec, f)
        os.replace(path + '.tmp', path)
        return key, f'{time.time() - t0:.1f}s'
    except Exception:
        return key, 'ERROR ' + traceback.format_exc()


ABLATION = [dict(omega=om, xi=xi, gam=xi, kappa=ka)
            for om in (0.0, 0.2) for xi in (0.1, 0.5, 1.0) for ka in (0.0, 1.0)]
SENS = ([('xi', dict(xi=v, gam=v)) for v in (0.1, 0.25, 1.0, 2.0)] +
        [('w', dict(w_lo=a, w_hi=b)) for a, b in ((0.50, 0.65), (0.80, 0.95))] +
        [('pi', dict(pi_scale=v)) for v in (0.5, 2.0)] +
        [('beta', dict(beta_scale=v)) for v in (0.5, 2.0)] +
        [('kappa', dict(kappa=v)) for v in (0.5, 2.0)] +
        [('rho_x', dict(rho_x=v)) for v in (0.1, 1.0)] +
        [('omega', dict(omega=v)) for v in (0.1, 0.5)] +
        [('M', dict()) for _ in (5, 20)])
SENS_M = [None] * (len(SENS) - 2) + [5, 20]


def jobs(exp):
    J = []
    if exp == 'E1':
        for r in range(E1_REPS):
            for N in sorted(E1_LOADS, reverse=True):
                J.append((exp, f'N{N}_r{r}', dict(N=N, r=r)))
    elif exp == 'E2':
        for r in range(E2_REPS):
            for (M, k) in E2_TOPO:
                for L in E2_LOADS:
                    J.append((exp, f'M{M}_k{k}_L{L}_r{r}', dict(M=M, k=k, L=L, r=r)))
    elif exp == 'E5':
        for r in range(ABL_REPS):
            for c in ABLATION:
                key = 'om{omega}_xi{xi}_ka{kappa}'.format(**c) + f'_r{r}'
                J.append((exp, key, dict(cfg=c, r=r)))
    elif exp == 'E6':
        for r in range(SENS_REPS):
            for (name, c), Mv in zip(SENS, SENS_M):
                tag = name + '_' + ('M%d' % Mv if Mv else '_'.join(f'{k}{v}' for k, v in c.items()))
                kw = dict(cfg=c, r=r, name=name)
                if Mv:
                    kw['M'] = Mv
                J.append((exp, f'{tag}_r{r}', kw))
    elif exp == 'E7':
        seeds = []
        s = 5000
        while len(seeds) < 20:
            sc = sim.gen_scenario(6, 2, s, BASE)
            if sim.local_option(sc)[2].all():
                seeds.append(s)
            s += 1
        for sd in seeds:
            J.append((exp, f'seed{sd}', dict(seed=sd)))
    return J


if __name__ == '__main__':
    exp = sys.argv[1]
    workers = int(sys.argv[2]) if len(sys.argv) > 2 else 2
    jl = [j for j in jobs(exp) if not os.path.exists(os.path.join(OUT, exp, j[1] + '.pkl'))]
    print(f'{exp}: {len(jl)} jobs to run', flush=True)
    t0 = time.time()
    with Pool(workers) as pool:
        for i, (key, st) in enumerate(pool.imap_unordered(job, jl, chunksize=1)):
            print(f'[{i + 1}/{len(jl)} {time.time() - t0:.0f}s] {key} {st}', flush=True)
