# GameEdge — simulation code

Code for the revised manuscript *GameEdge: A Game-Theoretic Framework for Joint Task Offloading and Resource Allocation in Edge Computing*. It reproduces every table and figure in Section 6.

## Files

| File | Content |
|---|---|
| `sim.py` | Scenario generator (same seeds and random draw order as the original study), parallel-execution latency model with per-slice M/M/1 queues (Eqs. 4–8), user best response (Algorithm 1), exact KKT server best response (Algorithm 2), utilities |
| `algos.py` | Algorithms 3–4 (proposed method), Greedy, Random, Centralized benchmark, PG-BR (adapted from Yan et al.), JTORA-LS (adapted from Tran & Pompili), metrics, ε-Nash test |
| `smallopt.py` | Exhaustive optimum of small instances (all association profiles, multi-start SLSQP per profile) |
| `run_exp.py` | Experiment runner; one result file per scenario, resumable |
| `analysis.py` | Statistics, figures (`figs/`), summary of all results |
| `quoted.py` | Every number quoted in the text, computed from the results |
| `kkt_check.py` | Original-problem KKT residuals of Algorithm 2 on all final solutions (Section 4.8) |
| `restricted_check.py` | Activity of the stability lower bounds at all final solutions; links the computed allocations to the restricted game of Theorem 1 (Sections 4.4, 4.8) |
| `a1_profiles.py` | Lists, per scenario, whether Assumption A1 holds for every user (`results/a1_profiles.csv`, Section 5.3) |

## Requirements

Python ≥ 3.11, NumPy ≥ 1.26, SciPy ≥ 1.11, Matplotlib ≥ 3.8.

## Reproducing the results

```bash
python run_exp.py E1 2   # main experiment: N = 10..100, 50 paired scenarios, 6 methods
python run_exp.py E2 2   # congestion and scale (M = 5, 10, 20; up to 200 users)
python run_exp.py E5 2   # fairness ablation (paper: E3)
python run_exp.py E6 2   # one-at-a-time sensitivity (paper: E4)
python run_exp.py E7 2   # exact optimum of 20 small instances (paper: E5)
python analysis.py       # tables, figures, results/summary.pkl
python quoted.py         # results/numbers.pkl (all numbers quoted in the paper)
python kkt_check.py      # KKT residuals of the server best responses
python restricted_check.py   # stability bounds inactive -> restricted-game KKT points
python a1_profiles.py    # which scenarios satisfy Assumption A1 for every user
```

The second argument is the number of worker processes. Each scenario is saved as `results/<experiment>/<key>.pkl`; an interrupted run continues where it stopped.

## Correctness checks

`test_core.py` compares the user best response with a 200,001-point grid search and the server best response with SciPy's SLSQP solver; both agree to within 10⁻⁸. `algos.eps_gap` implements the ε-stability test of Definition 1 exactly as described in Section 4.5.
