"""Every number quoted in the text, computed from the result files -> results/numbers.pkl"""
import pickle, glob, os
import numpy as np
import analysis as A

R = A.R
V = pickle.load(open(f'{R}/summary.pkl', 'rb'))
N = {}
f = lambda x, d=2: f'{x:.{d}f}'


def pf(p):
    return '< 0.001' if p < 0.001 else f'= {p:.3f}'


T6 = V['T6']
P = V['paired100']
# ---------------- E1 main
N['U100'] = f(T6['Proposed']['util_mean'][0], 3)
N['UMAX100'] = f(T6['Proposed']['util_max'][0], 3)
N['WQS100'] = f(T6['Proposed']['Wq_share'][0], 1)
N['WQ100'] = f(T6['Proposed']['Wq_ms'][0], 1)
N['PART100'] = f(T6['Proposed']['pct_part'][0], 1)
N['ORACLE100'] = f(V['oracle_adm_100'], 1)
N['COMMON100'] = f(V['common_frac_100'], 1)
for m, tag in zip(A.METH, ['P', 'G', 'R', 'C', 'PG', 'JT']):
    for k, key, d in (('T_ms', 'T', 2), ('adm', 'A', 2), ('T_pen1_ms', 'TP', 2), ('T_common_ms', 'TC', 2),
                      ('J', 'J', 4), ('J_common', 'JC', 4), ('J_pen', 'JP', 4), ('Csvc', 'CS', 4),
                      ('JFI_dem', 'JD', 4), ('JFI_lat', 'JL', 4), ('JFI_raw', 'JR', 4), ('LBF_w', 'LBF', 3),
                      ('T_pen2_ms', 'TP2', 2), ('pct_full', 'FULL', 1), ('util_mean', 'U', 3)):
        N[f'{key}_{tag}'] = f(T6[m][k][0], d)
    N[f'TSD_{tag}'] = f(T6[m]['T_ms'][1], 2)
for k, key, d in (('T_pen1_ms', 'DTP', 2), ('T_common_ms', 'DTC', 2), ('J_common', 'DJC', 4), ('J_pen', 'DJP', 4),
                  ('adm', 'DA', 2), ('T_pen2_ms', 'DTP2', 2), ('JFI_dem', 'DJD', 4), ('JFI_lat', 'DJL', 4), ('T_ms', 'DT', 2)):
    for m, tag in zip(A.METH[1:], ['G', 'R', 'C', 'PG', 'JT']):
        c = P[k][m]
        N[f'{key}_{tag}'] = f(c['mean'], d)
        N[f'{key}_{tag}_ABS'] = f(abs(c['mean']), d)
        N[f'{key}_{tag}_CI'] = f(c['ci'], d)
        N[f'{key}_{tag}_SD'] = f(c['sd'], d)
        N[f'{key}_{tag}_DZ'] = f(c['dz'], 2)
        N[f'{key}_{tag}_PT'] = pf(c['t_holm'])
        N[f'{key}_{tag}_PW'] = pf(c['w_holm'])

# per-scenario win counts at N=100
recs = [r for r in A.load('E1') if r['kw']['N'] == 100]
for m, tag in zip(A.METH[1:], ['G', 'R', 'C', 'PG', 'JT']):
    w = sum(r['Proposed']['T_pen1_ms'] < r[m]['T_pen1_ms'] for r in recs)
    N[f'WIN_TP_{tag}'] = str(int(w))
N['NREC100'] = str(len(recs))
allrec = A.load('E1')
fr_ok = [r for r in allrec if not r['Proposed']['converged'] and r['Proposed']['assoc_changes_last'] > 0 and r['Proposed']['residual'] <= 1e-4]
N['NFAIL_RESOK'] = str(len(fr_ok))
ch = [r['Proposed']['assoc_changes_last'] for r in allrec if not r['Proposed']['converged'] and r['Proposed']['assoc_changes_last'] > 0]
N['FAIL_CHG_MAX'] = str(int(max(ch))) if ch else '0'
N['FAIL_CHG_MED'] = f'{np.median(ch):.0f}' if ch else '0'

# convergence
cv = V['conv']
ok, tot = V['conv_total']
N['CONV_OK'] = str(ok); N['CONV_TOT'] = str(tot); N['CONV_PCT'] = f(100 * ok / tot, 1)
nf = sum(c['nfail'] for c in cv)
N['NFAIL'] = str(nf)
N['NFAIL_ASSOC'] = str(sum(c['fail_assoc'] for c in cv)); N['NFAIL_CONT'] = str(sum(c['fail_cont'] for c in cv))
fr = [c['fail_res'] for c in cv if c['fail_res'] is not None]
N['FAIL_RES_MAX'] = f'{max(x[1] for x in fr):.1e}' if fr else '—'
N['MAXDT_EXCL'] = f(max(abs(c['T_all'] - c['T_conv']) for c in cv), 2)
N['MAXDJ_EXCL'] = f(max(abs(c['J_all'] - c['J_conv']) for c in cv), 4)
c100 = [c for c in cv if c['N'] == 100][0]
N['ROUNDS100'] = f(c100['rounds'], 2); N['CONT100'] = f(c100['cont_last'], 1)
N['A1_MIN'] = f(min(c['A1'] for c in cv), 1); N['A1_MAX'] = f(max(c['A1'] for c in cv), 1)
N['A1EQ_MIN'] = f(min(c['A1eq'] for c in cv), 1); N['A1EQ_MAX'] = f(max(c['A1eq'] for c in cv), 1)
N['RT10'] = f(cv[0]['runtime'], 2); N['RT100'] = f(c100['runtime'], 2)
N['RTC10'] = f(cv[0]['rt_central'], 2); N['RTC100'] = f(c100['rt_central'], 2)
N['SC_MIN'] = f(min(c['scalars'] for c in cv), 0); N['SC_MAX'] = f(max(c['scalars'] for c in cv), 0)
N['SC100'] = f(c100['scalars'], 0); N['KB100'] = f(8 * c100['scalars'] / 1024, 1)
fails = {c['N']: c['nfail'] for c in cv if c['nfail']}
N['FAIL_LIST'] = ', '.join(f'{v} at $N={k}$' for k, v in sorted(fails.items()))
# eps
E = {(e['N'], e['m']): e for e in V['eps']}
for n in (20, 60, 100):
    for m, tag in (('Proposed', 'P'), ('Greedy', 'G'), ('Random', 'R')):
        e = E[(n, m)]
        N[f'EPS{n}_{tag}'] = f(e['max_mean'], 4); N[f'EPSMAX{n}_{tag}'] = f(e['max_max'], 4)
        N[f'EPSP2_{n}_{tag}'] = f(e['p2'], 1); N[f'EPSP3_{n}_{tag}'] = f(e['p3'], 1)
        N[f'EPSREJ{n}_{tag}'] = str(int(e['rej'])); N[f'EPSNREJ{n}_{tag}'] = str(int(e['nrej']))
        N[f'EPSC{n}_{tag}'] = f'{e["cont"]:.1e}'
# utilisation trend
S = V['S1']
N['U10'] = f(S['Proposed']['util_mean'][0], 3)
N['WQS10'] = f(S['Proposed']['Wq_share'][0], 1)
N['ADM_MIN_P'] = f(min(S['Proposed']['adm']), 1)

# ---------------- E2
if V.get('E2'):
    rows = V['E2']
    umax = max(rows, key=lambda r: r[('Proposed', 'util_mean')])
    N['E2_UMEAN_MAX'] = f(umax[('Proposed', 'util_mean')], 3)
    N['E2_UMEAN_MAX_CFG'] = f'$M={umax["M"]}$, $N={umax["N"]}$, $\\lambda_s={umax["L"]:g}$'
    um = max(rows, key=lambda r: r[('Proposed', 'util_max')])
    N['E2_UMAXMAX'] = f(um[('Proposed', 'util_max')], 3)
    N['E2_UMAXMAX_CFG'] = f'$M={um["M"]}$, $N={um["N"]}$, $\\lambda_s={um["L"]:g}$'
    N['E2_WQS_MAX'] = f(max(r[('Proposed', 'Wq_share')] for r in rows), 1)
    n08 = [r for r in rows if r[('Proposed', 'util_max')] >= 0.8]
    N['E2_N_GE08'] = str(len(n08)); N['E2_NCFG'] = str(len(rows))
    wins = sum(r[('pen_diff', 'Centralized')]['mean'] < 0 for r in rows)
    winsG = sum(r[('pen_diff', 'Greedy')]['mean'] < 0 for r in rows)
    winsJ = sum(r[('pen_diff', 'JTORA-LS')]['mean'] < 0 for r in rows)
    N['E2_WIN_C'] = str(wins); N['E2_WIN_G'] = str(winsG); N['E2_WIN_JT'] = str(winsJ)
    N['E2_CONV_MIN'] = f(min(r['conv'] for r in rows), 0)
    N['E2_CONV_MEAN'] = f(np.mean([r['conv'] for r in rows]), 1)
    ee = [r['eps_max'] for r in rows if 'eps_max' in r]
    if ee:
        N['E2_EPS_MIN'] = f(min(ee), 4); N['E2_EPS_MAX'] = f(max(ee), 4)
    N['E2_ADM_MIN_P'] = f(min(r[('Proposed', 'adm')] for r in rows), 1)
    hi = [r for r in rows if r['L'] == max(x['L'] for x in rows)]
    N['E2_ADM_HI_P'] = f(np.mean([r[('Proposed', 'adm')] for r in hi]), 1)
    N['E2_ADM_HI_C'] = f(np.mean([r[('Centralized', 'adm')] for r in hi]), 1)
    N['E2_ORACLE_HI'] = f(np.mean([r['oracle'] for r in hi]), 1)
    recs2 = A.load('E2')
    allconv = [r['Proposed']['converged'] for r in recs2]
    N['E2_CONV_ALL'] = f(100 * np.mean(allconv), 1); N['E2_RUNS'] = str(len(recs2))
    low = sorted([r for r in rows if r['conv'] < 90], key=lambda r: r['conv'])
    N['E2_NLOWCONV'] = str(len(low))
    N['E2_LOWCONV_LIST'] = '; '.join(f'$M={r["M"]}$, $N={r["N"]}$, $\\lambda_s={r["L"]:g}$: {r["conv"]:.0f}%' for r in low)
    nc = [r for r in recs2 if not r['Proposed']['converged']]
    N['E2_NC_RESOK'] = str(sum(r['Proposed']['residual'] <= 1e-4 for r in nc)); N['E2_NC'] = str(len(nc))
    N['E2_NC_ASSOC'] = str(sum(r['Proposed']['assoc_changes_last'] > 0 for r in nc))
    # penalised user cost per configuration (rejected = 1)
    G = {}
    for r in recs2:
        kw = r['kw']; G.setdefault((kw['M'], kw['k'], kw['L']), []).append(r)
    jw = 0; jdiff = []
    for key, rr in G.items():
        jp = lambda m: np.mean([np.where(r['users'][m]['adm'], r['users'][m]['J'], 1.0).mean() for r in rr])
        d = jp('Proposed') - jp('Centralized'); jdiff.append(d); jw += d < 0
    N['E2_JPEN_WIN_C'] = str(jw)
    lose = [r for r in rows if r[('pen_diff', 'Centralized')]['mean'] >= 0]
    N['E2_LOSE_C'] = '; '.join(f'$M={r["M"]}$, $N={r["N"]}$, $\\lambda_s={r["L"]:g}$ ({r[("pen_diff","Centralized")]["mean"]:+.1f} ms, Wilcoxon $p$ = {r[("pen_diff","Centralized")]["w_p"]:.2f})' for r in lose) or 'none'
    sig = sum(r[('pen_diff', 'Centralized')]['mean'] < 0 and r[('pen_diff', 'Centralized')]['w_p'] < 0.05 for r in rows)
    N['E2_WIN_C_SIG'] = str(sig)
    hiP = np.mean([r[('Proposed', 'T_pen1_ms')] for r in hi]); hiC = np.mean([r[('Centralized', 'T_pen1_ms')] for r in hi])
    N['E2_TPEN_HI_P'] = f(hiP, 1); N['E2_TPEN_HI_C'] = f(hiC, 1)
    N['E2_TADM_HI_P'] = f(np.mean([r[('Proposed', 'T_ms')] for r in hi]), 1)
    N['E2_TADM_HI_C'] = f(np.mean([r[('Centralized', 'T_ms')] for r in hi]), 1)

# ---------------- E3 ablation
if V.get('E5'):
    ab = {(r['omega'], r['xi'], r['kappa']): r for r in V['E5']}
    for key, r in ab.items():
        tag = f'{key[0]:g}_{key[1]:g}_{key[2]:g}'.replace('.', 'p')
        for k in ('JFI_raw', 'JFI_dem', 'JFI_lat', 'T_ms', 'J', 'adm'):
            N[f'AB_{k}_{tag}'] = f(r[k], 4 if 'JFI' in k or k == 'J' else 2)
            if k + '_p' in r:
                N[f'AB_{k}_{tag}_D'] = f(r[k + '_p']['mean'], 4 if 'JFI' in k or k == 'J' else 2)
                N[f'AB_{k}_{tag}_PW'] = pf(r[k + '_p']['w_p'])
    N['AB_REPS'] = str(min(r['reps'] for r in V['E5']))

# ---------------- E4 sensitivity
if V.get('E6'):
    rows = V['E6']
    dT = [abs(r['T_ms_p']['mean']) for r in rows if 'T_ms_p' in r]
    N['SENS_N'] = str(len(dT))
    big = sorted([r for r in rows if 'T_ms_p' in r], key=lambda r: -abs(r['T_ms_p']['mean']))
    N['SENS_TOP'] = big[0]['tag']; N['SENS_TOP_D'] = f(big[0]['T_ms_p']['mean'], 2)
    N['SENS_CONV_MIN'] = f(min(r['conv'] for r in rows), 0)
    N['SENS_REPS'] = str(min(r['reps'] for r in rows))
    for r in rows:
        if 'T_ms_p' in r:
            tag = r['tag'].replace(':', '_').replace('=', '').replace(',', '_').replace('.', 'p')
            N[f'S_{tag}_DT'] = f(r['T_ms_p']['mean'], 2)
            N[f'S_{tag}_DJ'] = f(r['J_p']['mean'], 4)
            N[f'S_{tag}_A'] = f(r['adm'], 2)
            N[f'S_{tag}_T'] = f(r['T_ms'], 2)
            N[f'S_{tag}_C'] = f(r['Csvc'], 4)
            N[f'S_{tag}_JD'] = f(r['JFI_dem'], 4)
            N[f'S_{tag}_U'] = f(r['util_mean'], 3)
            N[f'S_{tag}_CV'] = f(r['conv'], 0)
    nom = [r for r in rows if r['tag'] == 'nominal']
    if nom:
        N['S_NOM_T'] = f(nom[0]['T_ms'], 2); N['S_NOM_A'] = f(nom[0]['adm'], 2); N['S_NOM_C'] = f(nom[0]['Csvc'], 4)
        N['S_NOM_JD'] = f(nom[0]['JFI_dem'], 4); N['S_NOM_U'] = f(nom[0]['util_mean'], 3)

# ---------------- E5 optimum
if V.get('E7'):
    for m, tag in zip(A.METH, ['P', 'G', 'R', 'C', 'PG', 'JT']):
        e = V['E7'][m]
        N[f'OPT_{tag}'] = f(e['mean'], 4); N[f'OPTMAX_{tag}'] = f(e['max'], 4); N[f'OPT1_{tag}'] = f(e['within1'], 0)
        N[f'OPTGAP_{tag}'] = f(100 * (e['mean'] - 1), 1)
    N['OPT_N'] = str(V['E7_n']); N['OPT_ENUM'] = str(V['E7_enum_better'])

MF = pickle.load(open(f'{R}/matched_fair.pkl', 'rb'))
for m, tag in zip(A.METH, ['P', 'G', 'R', 'C', 'PG', 'JT']):
    N[f'MJ_{tag}'] = f(MF['J'][m], 4); N[f'NOFF_{tag}'] = f(MF['nOff'][m], 2)
    if m in MF['comps']:
        d, ci, dz, p = MF['comps'][m]
        N[f'MJD_{tag}'] = f(d, 4); N[f'MJCI_{tag}'] = f(ci, 4); N[f'MJP_{tag}'] = pf(p)
N['MNC'] = f(MF['nC'], 1)
XC = pickle.load(open(f'{R}/extra_checks.pkl', 'rb'))
N['A1_ALL'] = str(XC['a1_all']); N['A1_NOT'] = str(XC['a1_n'] - XC['a1_all'])
m_, e_ = f"{XC['srv_gain_max']:.1e}".split('e')
N['SRV_GAIN'] = f'${m_}\\times10^{{{int(e_)}}}$'
N['AUDIT_SCEN'] = str(XC['audit_scen']); N['AUDIT_USERS'] = f"{XC['audit_users']:,}"
KK = pickle.load(open(f'{R}/kkt_check.pkl', 'rb'))
def sci(v):
    m_, e_ = f'{v:.1e}'.split('e'); return f'${m_}\\times10^{{{int(e_)}}}$'
N['KKT_N'] = f"{KK['n']:,}"; N['KKT_STAT'] = sci(KK['stationarity (interior)'][0]); N['KKT_STAT_MED'] = sci(KK['stationarity (interior)'][1])
N['KKT_PRIM'] = sci(max(KK['primal feasibility'][0], 1e-16)); N['KKT_COMP'] = sci(max(KK['complementarity'][0], 1e-16))
RC = pickle.load(open(f'{R}/restricted_check.pkl', 'rb'))
N['RC_PAIRS'] = f"{RC['pairs']:,}"; N['RC_ACT'] = str(RC['active']); N['RC_MARGIN'] = f"{100*RC['min_margin']:.0f}"
N['CODE_URL'] = '[public repository URL — to be inserted by the authors]'
N['REF3_DETAILS'] = '[volume(issue), pages — to be completed by the authors]'
pickle.dump(N, open(f'{R}/numbers.pkl', 'wb'))
print(len(N), 'numbers')
