"""Original-problem KKT residuals of Algorithm 2 on every final solution of E1 (Proposed).
For each active server j and resource (CPU, BW): gradient of the ORIGINAL utility (15),
including the exact dispersion gradient omega*(q_k - qbar)/n_j, then
  multiplier lambda >= 0 of sum <= 1, multipliers mu_k >= 0 of the stability lower bounds.
Residuals: stationarity |g_k - lambda| (interior k), max(0, g_k - lambda) (k at lower bound),
primal feasibility, complementarity lambda*(1 - sum p). Reported relative to the magnitude of the gradient terms (revenue + operating cost + dispersion + latency)."""
import glob, pickle, numpy as np, sim
RHO = sim.RHO_MAX
def resid(sc, a, x, p, s):
    cfg = sc['cfg']; om, ka = cfg['omega'], cfg['kappa']; M = sc['M']
    out = []
    for j in range(M):
        idx = np.nonzero(a == j)[0]; n = len(idx)
        if n == 0: continue
        xs = x[idx]; q = 0.5 * (p[idx] + s[idx]); qbar = q.mean()
        disp = om * (q - qbar) / n if n >= 2 else 0.0
        for res_, cap, work, coef, share, c2 in (
            ('F', sc['F'][j], sc['C'][idx], sc['aF'][j], p[idx], 2 * cfg['xi']),
            ('B', sc['B'][j] * sc['c'][idx, j], sc['D'][idx], sc['aB'][j], s[idx], 2 * cfg['gam'])):
            e = sc['nu'][idx] * xs * work
            K = (ka / n) * xs * work / sc['Tmax'][idx]
            u = share * cap - e
            g = xs * coef - c2 * share - disp + K * cap / u ** 2          # dPhi/dshare (original)
            lb = e / (RHO * cap)
            at_lb = share <= lb * (1 + 1e-6) + 1e-12
            slack = 1 - share.sum()
            interior = ~at_lb
            if slack > 1e-8:
                lam = 0.0
            else:
                lam = max(0.0, np.median(g[interior])) if interior.any() else 0.0
            scale = max(np.max(np.abs(xs * coef) + c2 * share + np.abs(disp) + K * cap / u ** 2), 1e-12)   # size of the gradient terms
            stat = np.max(np.abs(g[interior] - lam)) if interior.any() else 0.0
            lbv = np.max(np.maximum(0, g[at_lb] - lam)) if at_lb.any() else 0.0
            prim = max(0.0, -slack, np.max(np.maximum(0, lb - share)))
            comp = abs(lam * slack)
            out.append((stat / scale, lbv / scale, prim, comp / scale, lam < 0))
    return out
if __name__ == '__main__':
    R = []
    recs = [pickle.load(open(f, 'rb')) for f in sorted(glob.glob('results/E1/*.pkl'))]
    for r in recs:
        N = r['kw']['N']
        sc = sim.gen_scenario(N, 10, 42 + 10000 * N + r['kw']['r'], dict(nu_lo=1.0, nu_hi=5.0))
        u = r['users']['Proposed']; a = u['a'].astype(int); x = u['x'].astype(float)
        # Algorithm 2 as used in Algorithm 3: linearize at the current shares, two passes
        p, s, _ = sim.server_solve(sc, a, x, u['p'].astype(float), u['s'].astype(float))
        R += resid(sc, a, x, p, s)
    R = np.array(R, float)
    names = ['stationarity (interior)', 'stationarity (at lower bound)', 'primal feasibility', 'complementarity']
    res = {nm: (float(np.max(R[:, k])), float(np.median(R[:, k])), float(np.percentile(R[:, k], 99))) for k, nm in enumerate(names)}
    res['n'] = len(R); res['neg_dual'] = int(R[:, 4].sum())
    for k, v in res.items(): print(k, v)
    pickle.dump(res, open('results/kkt_check.pkl', 'wb'))
