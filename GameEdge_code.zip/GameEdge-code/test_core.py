import numpy as np, time
from scipy.optimize import minimize
import sim
sc = sim.gen_scenario(40, 4, 42+400000)
N,M=sc['N'],sc['M']
# --- user BR vs brute-force grid
rng=np.random.default_rng(0)
ii=rng.integers(0,N,200); jj=rng.integers(0,M,200)
p=rng.uniform(0.05,0.5,200); s=rng.uniform(0.05,0.5,200)
f=p*sc['F'][jj]; r=s*sc['B'][jj]*sc['c'][ii,jj]; pc=sim.price_coef(sc,ii,jj,p,s)
t=time.time()
x,J,T,feas,_=sim.user_br(sc['C'][ii],sc['D'][ii],sc['floc'][ii],sc['nu'][ii],sc['Tmax'][ii],sc['w'][ii],sc['alpha'][ii],f,r,pc)
print('br time',time.time()-t)
g=np.linspace(1e-6,1,200001)[:,None]
Tg=sim.t_total(g,sc['C'][ii],sc['D'][ii],sc['nu'][ii],sc['floc'][ii],f,r)
st=(sc['nu'][ii]*(1-g)*sc['C'][ii]<=0.98*sc['floc'][ii])&(sc['nu'][ii]*g*sc['C'][ii]<=0.98*f)&(sc['nu'][ii]*g*sc['D'][ii]<=0.98*r)
Jg=np.where(st&(Tg<=sc['Tmax'][ii]), sc['w'][ii]*Tg/sc['Tmax'][ii]+sc['alpha'][ii]*g*pc, np.inf)
Jb=Jg.min(0)
print('feas agree', np.mean(feas==np.isfinite(Jb)), 'n feas',feas.sum())
m=feas&np.isfinite(Jb)
print('max J diff (br - grid)', np.max(J[m]-Jb[m]), 'min', np.min(J[m]-Jb[m]))
# --- server solver vs scipy for one server
a=np.full(N,-1); a[:12]=0; a[12:20]=1
x=np.where(a>=0, rng.uniform(0.2,1,N),0)
t=time.time(); P,S,inf=sim.server_solve(sc,a,x,omega=0.0,passes=1); print('solve time',time.time()-t, 'infeas',inf)
def neg(z, idx, j):
    n=len(idx); pp=z[:n]; ss=z[n:]
    PP=np.zeros(N); SS=np.zeros(N); PP[idx]=pp; SS[idx]=ss
    return -sim.server_utility(sc,a,x,PP,SS,omega=0.0)[j]
for j in [0,1]:
    idx=np.nonzero(a==j)[0]; n=len(idx)
    lbF=sc['nu'][idx]*x[idx]*sc['C'][idx]/(0.98*sc['F'][j])*1.0001
    lbB=sc['nu'][idx]*x[idx]*sc['D'][idx]/(0.98*sc['B'][j]*sc['c'][idx,j])*1.0001
    z0=np.r_[P[idx],S[idx]]
    cons=[{'type':'ineq','fun':lambda z,n=n:1-z[:n].sum()},{'type':'ineq','fun':lambda z,n=n:1-z[n:].sum()}]
    best=None
    for k in range(5):
        st0=np.r_[lbF+(1-lbF.sum())/n*rng.uniform(0.2,1,n), lbB+(1-lbB.sum())/n*rng.uniform(0.2,1,n)]
        res=minimize(neg,st0,args=(idx,j),bounds=list(zip(np.r_[lbF,lbB],np.ones(2*n))),constraints=cons,method='SLSQP',options={'maxiter':500,'ftol':1e-14})
        if best is None or res.fun<best.fun: best=res
    print('server',j,'ours',-neg(z0,idx,j),'scipy',-best.fun, 'sumP',P[idx].sum(),'sumS',S[idx].sum())
