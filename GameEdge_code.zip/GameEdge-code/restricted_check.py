"""Theorem 1 concerns the restricted game G_A with server strategy set (24). Algorithm 2 additionally
imposes x-dependent stability lower bounds p_ij >= nu_i x_i C_i/(rho_max F_j) (and the same for bandwidth).
This script counts, over all final E1 solutions of the proposed method, how many of these bounds are
active and the smallest relative margin share/bound - 1 -> results/restricted_check.pkl"""
import glob, pickle, numpy as np, sim
RHO = sim.RHO_MAX
pairs = act = 0; margin = np.inf
for f in sorted(glob.glob('results/E1/*.pkl')):
    r = pickle.load(open(f, 'rb')); N = r['kw']['N']
    sc = sim.gen_scenario(N, 10, 42 + 10000 * N + r['kw']['r'], dict(nu_lo=1.0, nu_hi=5.0))
    u = r['users']['Proposed']; a = u['a'].astype(int); x = u['x'].astype(float)
    p, s, _ = sim.server_solve(sc, a, x, u['p'].astype(float), u['s'].astype(float))
    for j in range(sc['M']):
        idx = np.nonzero(a == j)[0]
        if len(idx) == 0: continue
        for cap, work, sh in ((sc['F'][j], sc['C'][idx], p[idx]), (sc['B'][j] * sc['c'][idx, j], sc['D'][idx], s[idx])):
            lb = sc['nu'][idx] * x[idx] * work / (RHO * cap)
            act += int((sh <= lb * (1 + 1e-6) + 1e-12).sum()); pairs += len(idx)
            margin = min(margin, float(np.min(sh / lb - 1)))
res = dict(pairs=pairs, active=act, min_margin=margin)
print(res); pickle.dump(res, open('results/restricted_check.pkl', 'wb'))
