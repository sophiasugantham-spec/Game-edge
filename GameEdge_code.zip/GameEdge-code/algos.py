"""Algorithms 1-4 (Proposed), baselines, published-method adaptations, metrics, eps-gap."""
import time
import numpy as np
import sim
from sim import RHO_MAX, X_ACT

LOCAL, REJ = -1, -2


# ============================================================ helpers
def _cfg(sc, key, val):
    return sc['cfg'][key] if val is None else val


def capacity_lb(sc, users, sid, xs):
    """minimum stable shares (CPU, BW) of slots"""
    lbF = sc['nu'][users] * xs * sc['C'][users] / (RHO_MAX * sc['F'][sid])
    lbB = sc['nu'][users] * xs * sc['D'][users] / (RHO_MAX * sc['B'][sid] * sc['c'][users, sid])
    return lbF, lbB


def anticipate(sc, a, x, p, s, i, omega, kappa, fp_passes=2, solve_passes=1):
    """Algorithm 4 candidate evaluation: for user i and every server j, the server
    re-solves its allocation with i added (other users' x fixed); user i best-responds.
    Returns x_j, J_j, feasible_j for j = 0..M-1."""
    M = sc['M']
    base = np.nonzero((a >= 0) & (np.arange(sc['N']) != i))[0]
    users = np.r_[base, np.full(M, i)]
    sid = np.r_[a[base], np.arange(M)]
    lbF, lbB = capacity_lb(sc, base, a[base], x[base])
    remF = 1.0 - np.bincount(a[base], lbF, minlength=M)
    remB = 1.0 - np.bincount(a[base], lbB, minlength=M)
    j = np.arange(M)
    xcap = np.minimum(remF * RHO_MAX * sc['F'] / (sc['nu'][i] * sc['C'][i]),
                      remB * RHO_MAX * sc['B'] * sc['c'][i] / (sc['nu'][i] * sc['D'][i]))
    ok = xcap > 10 * X_ACT
    xg = np.clip(0.9 * xcap, 2 * X_ACT, 1.0)
    xs = np.r_[x[base], xg]
    xj = xg.copy()
    Jj = np.full(M, np.inf)
    fe = np.zeros(M, bool)
    pp = ss = None
    for _ in range(fp_passes):
        xs[len(base):] = np.where(ok, xg, 2 * X_ACT)
        pp, ss, inf = sim.solve_slots(sc, users, sid, xs, omega, kappa, None, None, solve_passes)
        pi_, si_ = pp[len(base):], ss[len(base):]
        f = pi_ * sc['F']
        r = si_ * sc['B'] * sc['c'][i]
        pc = sim.price_coef(sc, i, j, pi_, si_)
        xb, Jb, Tb, fb, xT = sim.user_br(sc['C'][i], sc['D'][i], sc['floc'][i], sc['nu'][i],
                                         sc['Tmax'][i], sc['w'][i], sc['alpha'][i], f, r, pc)
        fb = fb & ok & ~inf
        xj, Jj, fe = xb, np.where(fb, Jb, np.inf), fb
        xg = np.where(fb, np.minimum(xb, 0.9 * xcap), xg)
    return xj, Jj, fe


def continuous_stage(sc, a, x, p, s, omega, kappa, rho_x, eps, Tc_max):
    """Algorithm 3: relaxed block-synchronous best response for fixed association,
    with explicit feasibility correction of the shared capacity constraints."""
    hist = []
    M = sc['M']
    for t in range(Tc_max):
        act = np.nonzero(a >= 0)[0]
        xn = x.copy()
        if len(act):
            xb, Jb, Tb, fb, xT = sim.br_on_current(sc, a, x, p, s, act)
            xb = np.where(fb, xb, xT)
            xn[act] = (1 - rho_x) * x[act] + rho_x * xb
            # feasibility correction (projection of x onto the capacity-feasible set)
            lbF, lbB = capacity_lb(sc, act, a[act], xn[act])
            totF = np.bincount(a[act], lbF, minlength=M)
            totB = np.bincount(a[act], lbB, minlength=M)
            scale = np.minimum(1.0, 0.995 / np.maximum(np.maximum(totF, totB), 1e-300))
            xn[act] = xn[act] * scale[a[act]]
        pn, sn, inf = sim.server_solve(sc, a, xn, p, s, omega, kappa)
        res = max(np.max(np.abs(xn - x), initial=0), np.max(np.abs(pn - p), initial=0),
                  np.max(np.abs(sn - s), initial=0))
        x, p, s = xn, pn, sn
        hist.append(res)
        if res <= eps:
            break
    return x, p, s, hist


def finalize(sc, a, x, p, s):
    """Common feasibility check applied to every method's final profile."""
    a = a.copy(); x = x.copy(); p = p.copy(); s = s.copy()
    J0, T0, f0 = sim.local_option(sc)
    T, J, Cs = sim.user_eval(sc, a, x, p, s)
    st = sim.stable_mask(sc, a, x, p, s)
    bad = (a >= 0) & ((T > sc['Tmax'] * (1 + 1e-9)) | ~st)
    for i in np.nonzero(bad)[0]:
        a[i] = LOCAL if f0[i] else REJ
        x[i] = 0.0; p[i] = 0.0; s[i] = 0.0
    loc = a == LOCAL
    a[loc & ~f0] = REJ
    x[a < 0] = 0.0; p[a < 0] = 0.0; s[a < 0] = 0.0
    return a, x, p, s, int(bad.sum())


def cleanup(sc, a, x, p, s, omega, kappa, rho_x, eps, Tc_max, passes):
    """Feasibility cleanup: per pass remove the worst deadline/stability violator on each
    server (to local execution if feasible, otherwise rejected), then re-run Algorithm 3."""
    J0, T0, f0 = sim.local_option(sc)
    removed = 0
    hist = []
    for _ in range(passes):
        T, J, Cs = sim.user_eval(sc, a, x, p, s)
        st = sim.stable_mask(sc, a, x, p, s)
        viol = (a >= 0) & ((T > sc['Tmax'] * (1 + 1e-9)) | ~st)
        if not viol.any():
            break
        ratio = np.where(viol, T / sc['Tmax'] + (~st) * 1e3, -np.inf)
        for j in np.unique(a[viol]):
            members = np.nonzero(a == j)[0]
            k = members[np.argmax(ratio[members])]
            a[k] = LOCAL if f0[k] else REJ
            x[k] = 0.0; p[k] = 0.0; s[k] = 0.0
            removed += 1
        x, p, s, hist = continuous_stage(sc, a, x, p, s, omega, kappa, rho_x, eps, Tc_max)
        drop = (a >= 0) & (x <= X_ACT)
        a[drop] = np.where(f0[drop], LOCAL, REJ)
    a[(a == LOCAL) & ~f0] = REJ
    return a, x, p, s, removed, hist


# ============================================================ Proposed
def run_proposed(sc, omega=None, kappa=None, rho_x=None, eps=None, Tc_max=None, TA_max=None,
                 keep_hist=False):
    t0 = time.perf_counter()
    omega = _cfg(sc, 'omega', omega); kappa = _cfg(sc, 'kappa', kappa)
    rho_x = _cfg(sc, 'rho_x', rho_x); eps = _cfg(sc, 'eps', eps)
    Tc_max = _cfg(sc, 'Tc_max', Tc_max); TA_max = _cfg(sc, 'TA_max', TA_max)
    N, M = sc['N'], sc['M']
    J0, T0, f0 = sim.local_option(sc)
    a = np.full(N, LOCAL); x = np.zeros(N); p = np.zeros(N); s = np.zeros(N)
    rounds = []
    cont_total = 0
    scalars = 0.0
    res = np.inf
    hist = []
    converged = False
    for r in range(TA_max):
        a_old = a.copy()
        for i in range(N):
            xj, Jj, fe = anticipate(sc, a, x, p, s, i, omega, kappa)
            scalars += 9 * M
            Jl = J0[i] if f0[i] else np.inf
            jb = int(np.argmin(Jj))
            if fe[jb] and Jj[jb] < Jl:
                new_a, new_x = jb, xj[jb]
            else:
                new_a, new_x = LOCAL, 0.0
            if new_a != a[i] or abs(new_x - x[i]) > 1e-12:
                old = a[i]
                a[i] = new_a; x[i] = new_x
                if old >= 0 or new_a >= 0:
                    p, s, _ = sim.server_solve(sc, a, x, None, None, omega, kappa)
        x, p, s, hist = continuous_stage(sc, a, x, p, s, omega, kappa, rho_x, eps, Tc_max)
        cont_iters = len(hist)
        scalars += 3 * np.sum(a >= 0) * len(hist)
        drop = (a >= 0) & (x <= X_ACT)
        a[drop] = np.where(f0[drop], LOCAL, REJ)
        a, x, p, s, removed, h2 = cleanup(sc, a, x, p, s, omega, kappa, rho_x, eps, Tc_max,
                                          sc['cfg']['cleanup_passes'])
        if h2:
            hist = h2
            cont_iters += len(h2)
        cont_total += cont_iters
        res = hist[-1] if hist else 0.0
        changes = int(np.sum(a != a_old))
        rounds.append(dict(changes=changes, residual=res, cont_iters=cont_iters, removed=removed))
        if changes == 0 and res <= eps:
            converged = True
            break
    a, x, p, s, nfix = finalize(sc, a, x, p, s)
    out = dict(a=a, x=x, p=p, s=s, rounds=len(rounds), cont_last=rounds[-1]['cont_iters'],
               cont_total=cont_total, residual=res, converged=converged,
               assoc_changes_last=rounds[-1]['changes'], round_log=rounds,
               runtime=time.perf_counter() - t0, scalars_per_user=scalars / N, final_fix=nfix)
    if keep_hist:
        out['hist'] = hist
    return out


# ============================================================ Greedy / Random
def _baseline(sc, order_rule, seed_off=987654):
    t0 = time.perf_counter()
    N, M = sc['N'], sc['M']
    J0, T0, f0 = sim.local_option(sc)
    kappa = sc['cfg']['kappa']
    a = np.full(N, LOCAL); x = np.zeros(N); p = np.zeros(N); s = np.zeros(N)
    rng = np.random.default_rng(sc['seed'] + seed_off)
    Fn = sc['F'] / sc['F'].max(); Bn = sc['B'] / sc['B'].max()
    for i in range(N):
        xj, Jj, fe = anticipate(sc, a, x, p, s, i, 0.0, kappa)
        Jl = J0[i] if f0[i] else np.inf
        cand = fe & ~(Jj >= Jl)   # skip servers not better than a feasible local option
        if cand.any():
            if order_rule == 'greedy':
                n_after = np.bincount(a[a >= 0], minlength=M) + 1
                score = np.where(cand, (Fn + Bn) / n_after, -np.inf)
                j = int(np.argmax(score))
            else:
                perm = rng.permutation(M)
                j = int(perm[np.argmax(cand[perm])])
            a[i] = j; x[i] = xj[j]
            p, s, _ = sim.server_solve(sc, a, x, None, None, 0.0, kappa)
    x, p, s, hist = continuous_stage(sc, a, x, p, s, 0.0, kappa, sc['cfg']['rho_x'],
                                     sc['cfg']['eps'], sc['cfg']['Tc_max'])
    drop = (a >= 0) & (x <= X_ACT)
    a[drop] = np.where(f0[drop], LOCAL, REJ)
    a, x, p, s, removed, h2 = cleanup(sc, a, x, p, s, 0.0, kappa, sc['cfg']['rho_x'],
                                      sc['cfg']['eps'], sc['cfg']['Tc_max'], sc['cfg']['cleanup_passes'])
    a, x, p, s, nfix = finalize(sc, a, x, p, s)
    return dict(a=a, x=x, p=p, s=s, runtime=time.perf_counter() - t0)


def run_greedy(sc):
    return _baseline(sc, 'greedy')


def run_random(sc):
    return _baseline(sc, 'random')


# ============================================================ latency-optimal allocation
def kleinrock(sc, a, x):
    """Square-root (Kleinrock) allocation minimising the sum of M/M/1 slice sojourn times
    on every server (full allocation of CPU and bandwidth)."""
    N, M = sc['N'], sc['M']
    p = np.zeros(N); s = np.zeros(N)
    idx = np.nonzero(a >= 0)[0]
    if len(idx) == 0:
        return p, s
    sid = a[idx]
    xs = x[idx]
    aC = xs * sc['C'][idx]; eC = sc['nu'][idx] * aC
    aD = xs * sc['D'][idx]; dD = sc['nu'][idx] * aD
    cc = sc['c'][idx, sid]
    F = sc['F']; B = sc['B']
    RF = F - np.bincount(sid, eC, minlength=M)
    sq = np.sqrt(aC)
    SF = np.bincount(sid, sq, minlength=M)
    pf = (eC + sq * np.maximum(RF[sid], 0) / np.maximum(SF[sid], 1e-300)) / F[sid]
    RB = B - np.bincount(sid, dD / cc, minlength=M)
    sb = np.sqrt(aD / cc)
    SB = np.bincount(sid, sb, minlength=M)
    yb = np.sqrt(aD * cc) * np.maximum(RB[sid], 0) / np.maximum(SB[sid], 1e-300)
    ps = (yb + dD) / (B[sid] * cc)
    p[idx] = pf; s[idx] = ps
    return p, s


def equal_share(sc, a):
    N, M = sc['N'], sc['M']
    p = np.zeros(N)
    idx = np.nonzero(a >= 0)[0]
    n = np.bincount(a[idx], minlength=M)
    p[idx] = 1.0 / n[a[idx]]
    return p, p.copy()


def _lat_br(sc, i, f, r, pc):
    xb, Jb, Tb, fb, xT = sim.user_br(sc['C'][i], sc['D'][i], sc['floc'][i], sc['nu'][i],
                                     sc['Tmax'][i], sc['w'][i], sc['alpha'][i], f, r, pc)
    Tl = sim.t_total(xT, sc['C'][i], sc['D'][i], sc['nu'][i], sc['floc'][i], f, r)
    stab = (sc['nu'][i] * xT * sc['C'][i] <= RHO_MAX * f) & (sc['nu'][i] * xT * sc['D'][i] <= RHO_MAX * r) \
        & (sc['nu'][i] * (1 - xT) * sc['C'][i] <= RHO_MAX * sc['floc'][i])
    ok = stab & (Tl <= sc['Tmax'][i]) & (xT > X_ACT)
    return xT, np.where(ok, Tl, np.inf)


# ============================================================ Centralized benchmark
def run_centralized(sc, sweeps=10):
    """Centralised latency-minimising coordinate benchmark (as in the original notebook,
    with the revised latency model): sequential minimum-latency association using trial
    shares 1/(n_j+1), followed by coordinate refinement with square-root allocation."""
    t0 = time.perf_counter()
    N, M = sc['N'], sc['M']
    J0, T0, f0 = sim.local_option(sc)
    a = np.full(N, LOCAL); x = np.zeros(N)
    j_all = np.arange(M)
    for i in range(N):
        n_after = np.bincount(a[a >= 0], minlength=M) + 1
        sh = 1.0 / n_after
        f = sh * sc['F']; r = sh * sc['B'] * sc['c'][i]
        pc = sim.price_coef(sc, i, j_all, sh, sh)
        xT, Tj = _lat_br(sc, i, f, r, pc)
        Tl = T0[i] if f0[i] else np.inf
        jb = int(np.argmin(Tj))
        if Tj[jb] < Tl:
            a[i] = jb; x[i] = xT[jb]
    for _ in range(sweeps):
        p, s = kleinrock(sc, a, x)
        act = np.nonzero(a >= 0)[0]
        if len(act) == 0:
            break
        j = a[act]
        f = p[act] * sc['F'][j]; r = s[act] * sc['B'][j] * sc['c'][act, j]
        pc = sim.price_coef(sc, act, j, p[act], s[act])
        xT, Tj = _lat_br(sc, act, f, r, pc)
        xn = x.copy()
        xn[act] = np.where(np.isfinite(Tj), xT, x[act])
        d = np.max(np.abs(xn - x))
        x = 0.5 * x + 0.5 * xn
        if d <= sc['cfg']['eps']:
            break
    p, s = kleinrock(sc, a, x)
    a, x, p, s, nfix = finalize(sc, a, x, p, s)
    return dict(a=a, x=x, p=p, s=s, runtime=time.perf_counter() - t0)


# ============================================================ adapted published methods
def run_pgbr(sc, max_rounds=50):
    """Adapted from Yan et al. [9]: binary offloading game (x in {0,1}); servers share CPU and
    bandwidth equally among associated users; users run sequential best-response dynamics on
    their own normalised cost J_i until no user changes."""
    t0 = time.perf_counter()
    N, M = sc['N'], sc['M']
    J0, T0, f0 = sim.local_option(sc)
    a = np.full(N, LOCAL); x = np.zeros(N)
    j_all = np.arange(M)
    one = np.ones(M)
    conv = False
    for rnd in range(max_rounds):
        changed = 0
        for i in range(N):
            cnt = np.bincount(a[a >= 0], minlength=M)
            n_after = cnt + (a[i] != j_all)          # if already on j, n stays
            sh = 1.0 / n_after
            f = sh * sc['F']; r = sh * sc['B'] * sc['c'][i]
            T = sim.t_total(one, sc['C'][i], sc['D'][i], sc['nu'][i], sc['floc'][i], f, r)
            stab = (sc['nu'][i] * sc['C'][i] <= RHO_MAX * f) & (sc['nu'][i] * sc['D'][i] <= RHO_MAX * r)
            pc = sim.price_coef(sc, i, j_all, sh, sh)
            J = np.where(stab & (T <= sc['Tmax'][i]), sc['w'][i] * T / sc['Tmax'][i] + sc['alpha'][i] * pc, np.inf)
            Jl = J0[i] if f0[i] else np.inf
            jb = int(np.argmin(J))
            new = jb if J[jb] < Jl else LOCAL
            if not np.isfinite(min(J[jb], Jl)):
                new = LOCAL
            cur_J = Jl if a[i] < 0 else J[a[i]]
            if new != a[i] and min(J[jb], Jl) < cur_J - 1e-12:
                a[i] = new; x[i] = 1.0 if new >= 0 else 0.0
                changed += 1
        if changed == 0:
            conv = True
            break
    p, s = equal_share(sc, a)
    a, x, p, s, nfix = finalize(sc, a, x, p, s)
    return dict(a=a, x=x, p=p, s=s, runtime=time.perf_counter() - t0, rounds=rnd + 1, converged=conv)


def _server_cost(sc, users, j, xs):
    """sum of normalised user costs on server j under square-root allocation, and feasibility"""
    if len(users) == 0:
        return 0.0, True
    a = np.full(sc['N'], LOCAL); x = np.zeros(sc['N'])
    a[users] = j; x[users] = xs
    p, s = kleinrock(sc, a, x)
    T, J, Cs = sim.user_eval(sc, a, x, p, s)
    st = sim.stable_mask(sc, a, x, p, s)
    ok = np.all(st[users] & (T[users] <= sc['Tmax'][users]))
    return float(J[users].sum()), bool(ok)


def run_jtora(sc, max_sweeps=10, rej_cost=2.0):
    """Adapted from Tran and Pompili [5] (hJTORA): binary offloading, closed-form KKT
    (square-root) CPU/bandwidth allocation, and centralised local search over offloading
    decisions minimising the total normalised user cost (rejected users cost 2)."""
    t0 = time.perf_counter()
    N, M = sc['N'], sc['M']
    J0, T0, f0 = sim.local_option(sc)
    a = np.where(f0, LOCAL, REJ)
    members = [[] for _ in range(M)]
    cost_j = np.zeros(M)
    for sweep in range(max_sweeps):
        improved = 0
        for i in range(N):
            cur = a[i]
            own = J0[i] if cur == LOCAL else (rej_cost if cur == REJ else None)
            # cost of current configuration (user i included)
            if cur >= 0:
                rest = [u for u in members[cur] if u != i]
                c_rest, _ = _server_cost(sc, np.array(rest, int), cur, np.ones(len(rest)))
                base_delta = cost_j[cur] - c_rest        # contribution of i at cur
            else:
                base_delta = own
            best = (base_delta, cur, None)
            if cur != LOCAL and f0[i] and J0[i] < best[0] - 1e-12:
                best = (J0[i], LOCAL, None)
            for j in range(M):
                if j == cur:
                    continue
                newm = np.array(members[j] + [i], int)
                c_new, ok = _server_cost(sc, newm, j, np.ones(len(newm)))
                if not ok:
                    continue
                delta = c_new - cost_j[j]
                if delta < best[0] - 1e-12:
                    best = (delta, j, c_new)
            if best[1] != cur:
                if cur >= 0:
                    members[cur] = [u for u in members[cur] if u != i]
                    cost_j[cur], _ = _server_cost(sc, np.array(members[cur], int), cur, np.ones(len(members[cur])))
                a[i] = best[1]
                if best[1] >= 0:
                    members[best[1]].append(i)
                    cost_j[best[1]] = best[2]
                improved += 1
        if improved == 0:
            break
    x = (a >= 0).astype(float)
    p, s = kleinrock(sc, a, x)
    a, x, p, s, nfix = finalize(sc, a, x, p, s)
    return dict(a=a, x=x, p=p, s=s, runtime=time.perf_counter() - t0, sweeps=sweep + 1)


# ============================================================ metrics
def jain(v):
    v = np.asarray(v, float)
    d = len(v) * np.sum(v ** 2)
    return float(np.sum(v) ** 2 / d) if d > 0 else 1.0


def metrics(sc, out, Tid=None):
    a, x, p, s = out['a'], out['x'], out['p'], out['s']
    N, M = sc['N'], sc['M']
    T, J, Cs = sim.user_eval(sc, a, x, p, s)
    adm = a != REJ
    off = a >= 0
    full = off & (x >= 0.999)
    part = off & (x < 0.999)
    m = {}
    m['adm'] = 100 * adm.mean()
    m['T_ms'] = 1e3 * T[adm].mean() if adm.any() else np.nan
    m['T_pen1_ms'] = 1e3 * np.where(adm, T, sc['Tmax']).mean()
    m['T_pen2_ms'] = 1e3 * np.where(adm, T, 2 * sc['Tmax']).mean()
    m['J'] = J[adm].mean() if adm.any() else np.nan
    m['Phi'] = -m['J']
    m['Csvc'] = Cs[adm].mean() if adm.any() else np.nan
    m['Csvc_off'] = Cs[off].mean() if off.any() else 0.0
    m['n_off'] = off.sum(); m['pct_full'] = 100 * full.mean(); m['pct_part'] = 100 * part.mean()
    m['pct_local'] = 100 * (a == LOCAL).mean(); m['pct_rej'] = 100 * (a == REJ).mean()
    # utilisation (workload based)
    idx = np.nonzero(off)[0]
    sid = a[idx]
    rhoC = np.bincount(sid, sc['nu'][idx] * x[idx] * sc['C'][idx], minlength=M) / sc['F']
    rhoB = np.bincount(sid, sc['nu'][idx] * x[idx] * sc['D'][idx] / sc['c'][idx, sid], minlength=M) / sc['B']
    m['util_mean'] = rhoC.mean(); m['util_max'] = rhoC.max(); m['utilB_mean'] = rhoB.mean()
    m['util_active_mean'] = rhoC[rhoC > 0].mean() if (rhoC > 0).any() else 0.0
    m['cpu_alloc'] = 100 * np.bincount(sid, p[idx], minlength=M).mean()
    m['bw_alloc'] = 100 * np.bincount(sid, s[idx], minlength=M).mean()
    m['LBF_w'] = rhoC.max() / rhoC.mean() if rhoC.mean() > 0 else 1.0
    m['CV_util'] = rhoC.std() / rhoC.mean() if rhoC.mean() > 0 else 0.0
    # queueing delay on the critical branch
    loc_serv = (1 - x) * sc['C'] / sc['floc']
    Tl = sim.t_loc(x, sc['C'], sc['floc'], sc['nu'])
    wl = Tl - np.where(x < 1, loc_serv, 0)
    we = np.zeros(N); Te = np.zeros(N)
    if len(idx):
        f = p[idx] * sc['F'][sid]; r = s[idx] * sc['B'][sid] * sc['c'][idx, sid]
        Te[idx] = sim.t_edge(x[idx], sc['C'][idx], sc['D'][idx], sc['nu'][idx], f, r)
        we[idx] = Te[idx] - x[idx] * sc['D'][idx] / r - x[idx] * sc['C'][idx] / f
    W = np.where(Te > Tl, we, wl)
    m['Wq_ms'] = 1e3 * W[adm].mean() if adm.any() else np.nan
    m['Wq_share'] = 100 * W[adm].sum() / T[adm].sum() if adm.any() else np.nan
    m['Wq_edge_ms'] = 1e3 * np.average(we[idx], weights=sc['nu'][idx]) if len(idx) else 0.0
    # fairness
    jr, jd, wts, jr1, w1 = [], [], [], [], []
    for j in range(M):
        u = idx[sid == j]
        n = len(u)
        if n == 0:
            continue
        q = 0.5 * (p[u] + s[u])
        jr1.append(1.0 if n == 1 else jain(q)); w1.append(n)
        if n >= 2:
            dF = sc['nu'][u] * x[u] * sc['C'][u]; dF = dF / dF.sum()
            dB = sc['nu'][u] * x[u] * sc['D'][u] / sc['c'][u, j]; dB = dB / dB.sum()
            phi = 0.5 * (p[u] / dF + s[u] / dB)
            jr.append(jain(q)); jd.append(jain(phi)); wts.append(n)
    m['JFI_raw_all'] = np.average(jr1, weights=w1) if w1 else np.nan
    m['JFI_raw'] = np.average(jr, weights=wts) if wts else np.nan
    m['JFI_dem'] = np.average(jd, weights=wts) if wts else np.nan
    if Tid is None:
        Tid, _ = sim.ideal_and_oracle(sc)
    sat = np.clip(Tid / np.maximum(T, 1e-12), 0, 1)
    m['JFI_lat'] = jain(sat[adm]) if adm.any() else np.nan
    m['JFI_lat_all'] = jain(np.where(adm, sat, 0.0))
    m['active_servers'] = int((np.bincount(sid, minlength=M) > 0).sum())
    # Theorem 1, condition (A1): a strict (Slater) feasible point exists for every admitted
    # offloading user when its server guarantees (i) 99% of the final shares, or (ii) the
    # equal half-capacity shares 0.5/n_j used to initialise Algorithm 4.
    if len(idx):
        f = 0.99 * p[idx] * sc['F'][sid]; r = 0.99 * s[idx] * sc['B'][sid] * sc['c'][idx, sid]
        xi_ = x[idx]
        Tg = sim.t_total(xi_, sc['C'][idx], sc['D'][idx], sc['nu'][idx], sc['floc'][idx], f, r)
        strict = (sc['nu'][idx] * xi_ * sc['C'][idx] < RHO_MAX * f) & \
                 (sc['nu'][idx] * xi_ * sc['D'][idx] < RHO_MAX * r) & \
                 (sc['nu'][idx] * (1 - xi_) * sc['C'][idx] < RHO_MAX * sc['floc'][idx]) & (Tg < sc['Tmax'][idx])
        m['A1_pct'] = 100 * strict.mean()
        n = np.bincount(sid, minlength=M)[sid]
        sh = 0.5 / n
        fe = sh * sc['F'][sid]; re = sh * sc['B'][sid] * sc['c'][idx, sid]
        pc = sim.price_coef(sc, idx, sid, sh, sh)
        _, _, _, feq, _ = sim.user_br(sc['C'][idx], sc['D'][idx], sc['floc'][idx], sc['nu'][idx],
                                      sc['Tmax'][idx], sc['w'][idx], sc['alpha'][idx], fe, re, pc)
        m['A1_eq_pct'] = 100 * feq.mean()
        m['slack_min'] = float(np.min(1 - T[idx] / sc['Tmax'][idx]))
    else:
        m['A1_pct'] = m['A1_eq_pct'] = 100.0
        m['slack_min'] = np.nan
    users = dict(adm=adm, T=T, J=J, a=a.astype(np.int8), x=x.astype(np.float32),
                 p=p.astype(np.float32), s=s.astype(np.float32))
    return m, users


# ============================================================ epsilon-Nash test
def eps_gap(sc, out, omega=None, kappa=None, fp_passes=3):
    """Unilateral-deviation test on a final profile.
    Users: (i) continuous gap on the current server with fixed resources; (ii) association
    gap: best of local execution and every other server, where the receiving server
    re-optimises its allocation (Algorithm 2) and the user best-responds.
    Servers: utility gain from an exact re-solve of Algorithm 2."""
    omega = _cfg(sc, 'omega', omega); kappa = _cfg(sc, 'kappa', kappa)
    a, x, p, s = out['a'], out['x'], out['p'], out['s']
    N = sc['N']
    J0, T0, f0 = sim.local_option(sc)
    T, J, Cs = sim.user_eval(sc, a, x, p, s)
    adm = a != REJ
    gc = np.zeros(N)
    act = np.nonzero(a >= 0)[0]
    if len(act):
        xb, Jb, Tb, fb, _ = sim.br_on_current(sc, a, x, p, s, act)
        gc[act] = np.where(fb, np.maximum(J[act] - Jb, 0), 0)
    ga = np.zeros(N)
    rej_dev = 0
    for i in range(N):
        xj, Jj, fe = anticipate(sc, a, x, p, s, i, omega, kappa, fp_passes=fp_passes, solve_passes=2)
        if a[i] >= 0:
            Jj[a[i]] = np.inf      # staying is covered by the continuous gap
        alt = min(np.min(Jj), J0[i] if (f0[i] and a[i] != LOCAL) else np.inf)
        if adm[i]:
            ga[i] = max(J[i] - alt, 0.0)
        elif np.isfinite(alt):
            rej_dev += 1
    pn, sn, _ = sim.server_solve(sc, a, x, p, s, omega, kappa, passes=6)
    gs = sim.server_utility(sc, a, x, pn, sn, omega, kappa) - sim.server_utility(sc, a, x, p, s, omega, kappa)
    g = np.maximum(gc, ga)
    na = max(adm.sum(), 1)
    return dict(eps_user_max=g[adm].max() if adm.any() else 0.0,
                eps_user_mean=g[adm].mean() if adm.any() else 0.0,
                eps_cont_max=gc.max(), eps_assoc_max=ga.max(),
                pct_dev_1e3=100 * np.sum(g[adm] > 1e-3) / na,
                pct_dev_1e2=100 * np.sum(g[adm] > 1e-2) / na,
                rej_with_dev=rej_dev, n_rej=int((~adm).sum()),
                eps_server_max=float(np.max(gs)) if len(gs) else 0.0)
