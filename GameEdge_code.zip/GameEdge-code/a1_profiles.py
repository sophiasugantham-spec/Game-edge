"""Lists, for every final solution of E1, whether Assumption A1 (99% guaranteed shares) holds for
every admitted offloading user -> results/a1_profiles.csv"""
import glob, pickle, csv
rows = []
for f in sorted(glob.glob('results/E1/*.pkl')):
    r = pickle.load(open(f, 'rb'))
    N, rep = r['kw']['N'], r['kw']['r']
    rows.append(dict(N=N, repetition=rep, seed=42 + 10000 * N + rep,
                     A1_pct_users=round(r['Proposed']['A1_pct'], 3),
                     A1_all_users=int(r['Proposed']['A1_pct'] >= 100 - 1e-9)))
rows.sort(key=lambda z: (z['N'], z['repetition']))
with open('results/a1_profiles.csv', 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print(sum(r['A1_all_users'] for r in rows), 'of', len(rows), 'profiles satisfy A1 for all users')
