"""Analysis of all experiments -> tables, figures and a JSON of every number quoted in the paper."""
import os, glob, pickle, json, re
import numpy as np
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

R = '/home/claude/gameedge/results'
FIG = '/home/claude/gameedge/figs'
METH = ['Proposed', 'Greedy', 'Random', 'Centralized', 'PG-BR', 'JTORA-LS']
COL = {'Proposed': '#1f4e9c', 'Greedy': '#d1495b', 'Random': '#8c8c8c', 'Centralized': '#2a9d8f',
       'PG-BR': '#e9a03b', 'JTORA-LS': '#7b4fa0'}
MK = {'Proposed': 'o', 'Greedy': 's', 'Random': '^', 'Centralized': 'D', 'PG-BR': 'v', 'JTORA-LS': 'P'}
plt.rcParams.update({'font.size': 20, 'axes.titlesize': 21, 'axes.labelsize': 20, 'xtick.labelsize': 17,
                     'ytick.labelsize': 17, 'legend.fontsize': 16, 'font.family': 'DejaVu Serif',
                     'lines.linewidth': 2.0, 'lines.markersize': 7})


def load(exp):
    out = []
    for f in sorted(glob.glob(os.path.join(R, exp, '*.pkl'))):
        with open(f, 'rb') as fh:
            out.append(pickle.load(fh))
    return out


def ci95(v):
    v = np.asarray(v, float); v = v[np.isfinite(v)]
    if len(v) < 2:
        return np.nan
    return stats.t.ppf(0.975, len(v) - 1) * v.std(ddof=1) / np.sqrt(len(v))


def boot_ci(v, B=4000, seed=1):
    v = np.asarray(v, float); v = v[np.isfinite(v)]
    rng = np.random.default_rng(seed)
    bs = rng.choice(v, (B, len(v))).mean(1)
    return np.percentile(bs, [2.5, 97.5])


def holm(pvals):
    p = np.asarray(pvals, float)
    order = np.argsort(p)
    adj = np.empty_like(p)
    m = len(p)
    run = 0.0
    for k, idx in enumerate(order):
        run = max(run, (m - k) * p[idx])
        adj[idx] = min(run, 1.0)
    return adj


def paired(a, b):
    """paired comparison a - b"""
    a = np.asarray(a, float); b = np.asarray(b, float)
    m = np.isfinite(a) & np.isfinite(b)
    d = a[m] - b[m]
    sd = d.std(ddof=1)
    tp = stats.ttest_rel(a[m], b[m]).pvalue if sd > 0 else 1.0
    try:
        wp = stats.wilcoxon(d).pvalue if np.any(d != 0) else 1.0
    except ValueError:
        wp = 1.0
    return dict(mean=d.mean(), ci=ci95(d), sd=sd, dz=d.mean() / sd if sd > 0 else 0.0, t_p=tp, w_p=wp, n=len(d))


def E(recs, meth, key, cond=None):
    v = [r[meth][key] for r in recs if (cond is None or cond(r))]
    return np.array(v, float)


V = {}   # every quoted number


def fmt(x, d=2):
    return f'{x:.{d}f}'


def pstr(p):
    if p < 1e-4:
        return '< 10⁻⁴'
    if p < 0.001:
        return '< 0.001'
    return f'{p:.3f}'


# ======================================================================== E1
def analyse_E1():
    recs = load('E1')
    if not recs:
        return None
    byN = {}
    for r in recs:
        byN.setdefault(r['kw']['N'], []).append(r)
    Ns = sorted(byN)
    V['E1_reps'] = min(len(byN[n]) for n in Ns)
    # common-admitted response time
    for n in Ns:
        for r in byN[n]:
            us = r['users']
            common = np.logical_and.reduce([us[m]['adm'] for m in METH])
            r['common_frac'] = common.mean()
            for m in METH:
                r[m]['T_common_ms'] = 1e3 * us[m]['T'][common].mean() if common.any() else np.nan
                r[m]['J_common'] = us[m]['J'][common].mean() if common.any() else np.nan
                r[m]['J_pen'] = np.where(us[m]['adm'], us[m]['J'], 1.0).mean()
    keys = ['T_ms', 'T_common_ms', 'T_pen1_ms', 'T_pen2_ms', 'adm', 'J', 'J_common', 'J_pen', 'Csvc', 'Wq_ms', 'Wq_share',
            'util_mean', 'util_max', 'cpu_alloc', 'bw_alloc', 'JFI_raw', 'JFI_raw_all', 'JFI_dem',
            'JFI_lat', 'LBF_w', 'CV_util', 'pct_full', 'pct_part', 'pct_local', 'pct_rej', 'runtime',
            'n_off', 'active_servers']
    S = {m: {k: {'mean': [], 'ci': [], 'sd': []} for k in keys} for m in METH}
    for n in Ns:
        for m in METH:
            for k in keys:
                v = E(byN[n], m, k)
                S[m][k]['mean'].append(np.nanmean(v)); S[m][k]['sd'].append(np.nanstd(v, ddof=1))
                S[m][k]['ci'].append(ci95(v))
    # ---------- figure 2: performance vs load
    panels = [('T_ms', 'Resp. time, admitted (ms)'), ('T_pen1_ms', 'Penalized resp. time (ms)'),
              ('adm', 'Admission rate (%)'), ('J', 'Mean user cost $J_i$'),
              ('util_mean', 'Mean server utilization $\\rho_j$'), ('Wq_ms', 'Queueing delay (ms)')]
    fig, axs = plt.subplots(3, 2, figsize=(11, 14))
    for ax, (k, lab), tag in zip(axs.flat, panels, 'abcdef'):
        for m in METH:
            mu = np.array(S[m][k]['mean']); c = np.array(S[m][k]['ci'])
            ax.plot(Ns, mu, marker=MK[m], color=COL[m], label=m)
            ax.fill_between(Ns, mu - c, mu + c, color=COL[m], alpha=0.15)
        ax.set_xlabel('Number of users $N$'); ax.set_ylabel(lab); ax.set_title(f'({tag})', loc='left')
        ax.grid(alpha=0.3)
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc='lower center', ncol=3, fontsize=17, frameon=False)
    fig.tight_layout(rect=[0, 0.06, 1, 1]); fig.savefig(os.path.join(FIG, 'fig2_performance.png'), dpi=200); plt.close(fig)
    # ---------- figure 3: fairness + load balance
    panels = [('JFI_dem', 'Demand-normalised JFI'), ('JFI_lat', 'Latency-satisfaction JFI'),
              ('LBF_w', 'Workload LBF $\\max_j\\rho_j/\\bar\\rho$')]
    fig, axs = plt.subplots(1, 3, figsize=(12.5, 5.2))
    for ax, (k, lab), tag in zip(axs, panels, 'abc'):
        for m in METH:
            mu = np.array(S[m][k]['mean']); c = np.array(S[m][k]['ci'])
            ax.plot(Ns, mu, marker=MK[m], color=COL[m], label=m)
            ax.fill_between(Ns, mu - c, mu + c, color=COL[m], alpha=0.15)
        ax.set_xlabel('Number of users $N$'); ax.set_ylabel(lab); ax.set_title(f'({tag})', loc='left'); ax.grid(alpha=0.3)
    axs[2].legend(ncol=2, fontsize=13)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, 'fig3_fairness.png'), dpi=200); plt.close(fig)
    # ---------- N = 100 table (mean +- sd), with bootstrap CI for bounded JFI
    n100 = byN[max(Ns)]
    N100 = max(Ns)
    V['E1_Nmax'] = N100
    T6 = {}
    for m in METH:
        T6[m] = {}
        for k in keys + ['Phi']:
            v = E(n100, m, k if k != 'Phi' else 'J') * (-1 if k == 'Phi' else 1)
            T6[m][k] = (np.nanmean(v), np.nanstd(v, ddof=1))
    V['T6'] = T6
    V['oracle_adm_100'] = np.mean([r['oracle_adm'] for r in n100])
    V['common_frac_100'] = 100 * np.mean([r['common_frac'] for r in n100])
    # ---------- paired tests at N=100 (Holm within each metric family)
    fam = {}
    for k in ['T_ms', 'T_common_ms', 'T_pen1_ms', 'T_pen2_ms', 'J', 'J_common', 'J_pen', 'adm', 'JFI_dem', 'JFI_lat']:
        comps = {}
        for m in METH[1:]:
            comps[m] = paired(E(n100, 'Proposed', k), E(n100, m, k))
        adj_t = holm([c['t_p'] for c in comps.values()])
        adj_w = holm([c['w_p'] for c in comps.values()])
        for (m, c), at, aw in zip(comps.items(), adj_t, adj_w):
            c['t_holm'] = at; c['w_holm'] = aw
        fam[k] = comps
    V['paired100'] = fam
    # ---------- convergence (Proposed)
    conv = []
    for n in Ns:
        rr = byN[n]
        c = np.array([r['Proposed']['converged'] for r in rr], bool)
        res = np.array([r['Proposed']['residual'] for r in rr])
        alc = np.array([r['Proposed']['assoc_changes_last'] for r in rr])
        failed = ~c
        conv.append(dict(N=n, rounds=np.mean([r['Proposed']['rounds'] for r in rr]),
                         cont_last=np.mean([r['Proposed']['cont_last'] for r in rr]),
                         cont_total=np.mean([r['Proposed']['cont_total'] for r in rr]),
                         res_all=res.mean(), res_conv=res[c].mean() if c.any() else np.nan,
                         rate=100 * c.mean(), nfail=int(failed.sum()),
                         fail_res=(res[failed].min(), res[failed].max()) if failed.any() else None,
                         fail_assoc=int(np.sum(failed & (alc > 0))),
                         fail_cont=int(np.sum(failed & (alc == 0))),
                         T_all=np.mean([r['Proposed']['T_ms'] for r in rr]),
                         T_conv=np.mean([r['Proposed']['T_ms'] for r, cc in zip(rr, c) if cc]) if c.any() else np.nan,
                         J_all=np.mean([r['Proposed']['J'] for r in rr]),
                         J_conv=np.mean([r['Proposed']['J'] for r, cc in zip(rr, c) if cc]) if c.any() else np.nan,
                         runtime=np.mean([r['Proposed']['runtime'] for r in rr]),
                         rt_central=np.mean([r['Centralized']['runtime'] for r in rr]),
                         scalars=np.mean([r['Proposed']['scalars_per_user'] for r in rr]),
                         A1=np.mean([r['Proposed']['A1_pct'] for r in rr]),
                         A1all=int(sum(r['Proposed']['A1_pct'] >= 100 - 1e-9 for r in rr)),
                         A1eq=np.mean([r['Proposed']['A1_eq_pct'] for r in rr])))
    V['conv'] = conv
    allc = np.concatenate([[r['Proposed']['converged'] for r in byN[n]] for n in Ns]).astype(bool)
    V['conv_total'] = (int(allc.sum()), len(allc))
    # ---------- eps-gap
    eps = []
    for n in Ns:
        rr = [r for r in byN[n] if 'eps_user_max' in r['Proposed']]
        if not rr:
            continue
        for m in ('Proposed', 'Greedy', 'Random'):
            g = lambda k: np.array([r[m][k] for r in rr], float)
            eps.append(dict(N=n, m=m, max_mean=g('eps_user_max').mean(), max_max=g('eps_user_max').max(),
                            mean=g('eps_user_mean').mean(), cont=g('eps_cont_max').mean(),
                            assoc=g('eps_assoc_max').mean(),
                            p3=g('eps_pct_dev_1e3').mean(), p2=g('eps_pct_dev_1e2').mean(),
                            rej=g('eps_rej_with_dev').sum(), nrej=g('eps_n_rej').sum(),
                            srv=g('eps_server_max').max(), runs=len(rr)))
    V['eps'] = eps
    # ---------- residual history figure (N = 100)
    H = [r['Proposed']['hist'] for r in n100 if 'hist' in r['Proposed']]
    if H:
        L = max(len(h) for h in H)
        A = np.full((len(H), L), np.nan)
        for i, h in enumerate(H):
            A[i, :len(h)] = h
        mu = np.nanmean(A, 0); cnt = np.sum(np.isfinite(A), 0)
        sd = np.nanstd(A, 0)
        fig, ax = plt.subplots(figsize=(9, 5.5))
        it = np.arange(1, L + 1)
        ax.semilogy(it, mu, color=COL['Proposed'], label='Mean residual $\\Delta_c$')
        lo = np.maximum(mu - 1.96 * sd / np.sqrt(np.maximum(cnt, 1)), mu * 0.05)
        ax.fill_between(it, lo, mu + 1.96 * sd / np.sqrt(np.maximum(cnt, 1)), color=COL['Proposed'], alpha=0.2)
        ax.axhline(1e-4, ls='--', color='k', label='Tolerance $\\varepsilon=10^{-4}$')
        ax.set_xlabel('Continuous iteration $t$ (final association round)'); ax.set_ylabel('Residual')
        ax.grid(alpha=0.3, which='both'); ax.legend()
        fig.tight_layout(); fig.savefig(os.path.join(FIG, 'fig5_convergence.png'), dpi=200); plt.close(fig)
    V['S1'] = {m: {k: S[m][k]['mean'] for k in keys} for m in METH}
    V['Ns'] = Ns
    return byN


# ======================================================================== E2
def analyse_E2():
    recs = load('E2')
    if not recs:
        return None
    G = {}
    for r in recs:
        kw = r['kw']
        G.setdefault((kw['M'], kw['k'], kw['L']), []).append(r)
    rows = []
    for (M, k, L), rr in sorted(G.items()):
        row = dict(M=M, k=k, N=M * k, L=L, reps=len(rr))
        for m in METH:
            for key in ('util_mean', 'util_max', 'Wq_share', 'Wq_ms', 'adm', 'T_ms', 'T_pen1_ms', 'J', 'JFI_dem', 'pct_part'):
                row[(m, key)] = np.mean([r[m][key] for r in rr])
        row['conv'] = 100 * np.mean([r['Proposed']['converged'] for r in rr])
        row['oracle'] = np.mean([r['oracle_adm'] for r in rr])
        if 'eps_user_max' in rr[0]['Proposed']:
            row['eps_max'] = np.mean([r['Proposed']['eps_user_max'] for r in rr])
            row['eps_p2'] = np.mean([r['Proposed']['eps_pct_dev_1e2'] for r in rr])
        # paired penalized response time vs Greedy and Centralized
        for m in ('Greedy', 'Centralized', 'JTORA-LS'):
            row[('pen_diff', m)] = paired([r['Proposed']['T_pen1_ms'] for r in rr], [r[m]['T_pen1_ms'] for r in rr])
            row[('J_diff', m)] = paired([r['Proposed']['J'] for r in rr], [r[m]['J'] for r in rr])
        rows.append(row)
    V['E2'] = rows
    # figure 7: utilization and penalized response time vs load for each topology
    topo = sorted({(r['M'], r['k']) for r in rows})
    fig, axs = plt.subplots(1, 3, figsize=(12.5, 5.4))
    tcol = ['#1f4e9c', '#d1495b', '#2a9d8f', '#e9a03b', '#7b4fa0']
    for t, cc in zip(topo, tcol):
        rr = [r for r in rows if (r['M'], r['k']) == t]
        Ls = [r['L'] for r in rr]
        lab = f'M={t[0]}, N={t[0]*t[1]}'
        axs[0].plot(Ls, [r[('Proposed', 'util_mean')] for r in rr], '-o', color=cc, label=lab)
        axs[0].plot(Ls, [r[('Proposed', 'util_max')] for r in rr], '--^', color=cc, mfc='white')
        axs[1].plot(Ls, [r[('Proposed', 'Wq_share')] for r in rr], '-o', color=cc, label=lab)
    axs[0].set_xlabel('Arrival-rate scale $\\lambda_s$'); axs[0].set_ylabel('Utilization (solid mean, dashed max)')
    axs[1].set_xlabel('Arrival-rate scale $\\lambda_s$'); axs[1].set_ylabel('Queueing share of $T$ (%)')
    rr = [r for r in rows if (r['M'], r['k']) == (10, 10)]
    for m in METH:
        axs[2].plot([r['L'] for r in rr], [r[(m, 'T_pen1_ms')] for r in rr], marker=MK[m], color=COL[m], label=m)
    axs[2].set_xlabel('Arrival-rate scale $\\lambda_s$'); axs[2].set_ylabel('Penalized resp. time (ms)')
    for ax, tg in zip(axs, 'abc'):
        ax.grid(alpha=0.3); ax.set_title(f'({tg})', loc='left')
    axs[0].legend(fontsize=13, loc='lower right'); axs[1].legend(fontsize=13, loc='lower right'); axs[2].legend(fontsize=13, ncol=1)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, 'fig7_congestion.png'), dpi=200); plt.close(fig)
    return rows


# ======================================================================== E5 / E6
def nominal100(byN, reps):
    if byN is None:
        return None
    rr = sorted(byN[100], key=lambda r: r['kw']['r'])[:reps]
    return {r['kw']['r']: r['Proposed'] for r in rr}


def analyse_E5(byN):
    recs = load('E5')
    if not recs:
        return None
    G = {}
    for r in recs:
        c = r['kw']['cfg']
        G.setdefault((c['omega'], c['xi'], c['kappa']), {})[r['kw']['r']] = r['Proposed']
    nom = G.get((0.2, 0.5, 1.0))
    rows = []
    for key, d in sorted(G.items()):
        rs = sorted(d)
        row = dict(omega=key[0], xi=key[1], kappa=key[2], reps=len(rs))
        row['n_multi'] = int(sum(np.isfinite(d[r]['JFI_dem']) for r in rs))
        for k in ('JFI_raw', 'JFI_dem', 'JFI_lat', 'T_ms', 'J', 'adm'):
            row[k] = np.nanmean([d[r][k] for r in rs])
            if nom is not None and key != (0.2, 0.5, 1.0):
                common = [r for r in rs if r in nom]
                row[k + '_p'] = paired([d[r][k] for r in common], [nom[r][k] for r in common])
        rows.append(row)
    V['E5'] = rows
    return rows


def analyse_E6(byN):
    recs = load('E6')
    if not recs:
        return None
    nom = nominal100(byN, 30)
    G = {}
    for r in recs:
        kw = r['kw']
        tag = kw['name'] + ':' + (str(kw['M']) if 'M' in kw else ','.join(f'{k}={v}' for k, v in kw['cfg'].items()))
        G.setdefault(tag, {})[kw['r']] = r['Proposed']
    rows = []
    for tag, d in G.items():
        rs = sorted(d)
        row = dict(tag=tag, reps=len(rs))
        for k in ('T_ms', 'adm', 'J', 'Csvc', 'JFI_dem', 'util_mean', 'pct_part'):
            row[k] = np.mean([d[r][k] for r in rs])
        row['conv'] = 100 * np.mean([d[r]['converged'] for r in rs])
        if nom:
            common = [r for r in rs if r in nom]
            for k in ('T_ms', 'J', 'adm'):
                row[k + '_p'] = paired([d[r][k] for r in common], [nom[r][k] for r in common])
        rows.append(row)
    # figure 6: paired change of response time and user cost per one-at-a-time parameter change
    lab = {'xi': 'ξ=γ', 'w': 'w range', 'pi': 'π/β ratio ×', 'beta': 'β scale', 'kappa': 'κ', 'rho_x': 'ρx',
           'omega': 'ωf', 'M': 'M'}
    rr = [r for r in rows if 'T_ms_p' in r and not r['tag'].startswith('beta')]

    def short(tag):
        n, v = tag.split(':', 1)
        if n == 'w':
            a, b = [x.split('=')[1] for x in v.split(',')]
            return f'w {a}–{b}'
        if n == 'M':
            return f'M={v}'
        if n == 'pi':
            return f'π/β ratio ×{v.split("=")[1]}'
        return f'{lab[n]}={v.split(",")[0].split("=")[1]}'
    order = ['xi', 'w', 'pi', 'beta', 'kappa', 'rho_x', 'omega', 'M']
    rr.sort(key=lambda r: (order.index(r['tag'].split(':')[0]), r['tag']))
    if rr:
        fig, axs = plt.subplots(1, 2, figsize=(11, 7))
        y = np.arange(len(rr))
        for ax, k, xl in ((axs[0], 'T_ms_p', 'Δ response time vs nominal (ms)'), (axs[1], 'J_p', 'Δ user cost $\\bar J$ vs nominal')):
            mu = [r[k]['mean'] for r in rr]; ci = [r[k]['ci'] for r in rr]
            ax.barh(y, mu, xerr=ci, color=COL['Proposed'], alpha=0.8, capsize=4)
            ax.axvline(0, color='k', lw=1)
            ax.set_yticks(y); ax.set_yticklabels([short(r['tag']) for r in rr]); ax.invert_yaxis()
            ax.set_xlabel(xl); ax.grid(alpha=0.3, axis='x')
        axs[0].set_title('(a)', loc='left'); axs[1].set_title('(b)', loc='left')
        fig.tight_layout(); fig.savefig(os.path.join(FIG, 'fig6_sensitivity.png'), dpi=200); plt.close(fig)
    if nom:
        rs = sorted(nom)
        row = dict(tag='nominal', reps=len(rs))
        for k in ('T_ms', 'adm', 'J', 'Csvc', 'JFI_dem', 'util_mean', 'pct_part'):
            row[k] = np.mean([nom[r][k] for r in rs])
        row['conv'] = 100 * np.mean([nom[r]['converged'] for r in rs])
        rows.append(row)
    V['E6'] = rows
    return rows


def analyse_E7():
    recs = load('E7')
    if not recs:
        return None
    out = {}
    for m in METH:
        ratio = np.array([r[m]['cost'] / r['opt'] for r in recs])
        out[m] = dict(mean=ratio.mean(), max=ratio.max(), within1=100 * np.mean(ratio <= 1.01),
                      ci=ci95(ratio))
    V['E7'] = out
    V['E7_n'] = len(recs)
    V['E7_enum_better'] = int(sum(r['src'] == 'enumeration' for r in recs))
    return out


def jsonable(o):
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if isinstance(o, np.bool_):
        return bool(o)
    return o


if __name__ == '__main__':
    byN = analyse_E1()
    analyse_E2(); analyse_E5(byN); analyse_E6(byN); analyse_E7()
    with open(os.path.join(R, 'summary.pkl'), 'wb') as f:
        pickle.dump(V, f)
    print('keys:', list(V))
